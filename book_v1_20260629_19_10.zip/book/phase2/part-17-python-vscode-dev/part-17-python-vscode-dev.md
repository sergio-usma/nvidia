# Parte 17 (Phase 2) — Entorno de Desarrollo Python con VSCode Remote SSH

## Introducción

Los capítulos de la Fase 1 convirtieron el Jetson en un servidor de inferencia de clase enterprise. Esta primera parte de la Fase 2 da un paso diferente: configurar el Jetson como un entorno de desarrollo Python remoto al que se accede cómodamente desde Windows o macOS usando Visual Studio Code con la extensión Remote SSH.

Con esta configuración, el Jetson es el servidor donde se ejecuta el código — con su GPU de 275 TOPS, sus 64 GB de RAM unificada y todos los modelos instalados — mientras que su computadora actúa como interfaz gráfica. Puede editar código, depurar, ver gráficas y ejecutar notebooks Jupyter, todo con la apariencia de un entorno local pero el poder del Jetson.

> **NOTA sobre Part 11 original:** Este capítulo integra y expande el contenido planeado para la Parte 11 (Python + PyTorch + AI frameworks). Al ubicarlo en la Fase 2, el lector tiene todos los motores de inferencia instalados y puede experimentar con ellos directamente desde Python, lo que hace los ejemplos mucho más prácticos e inmediatos.

**Prerequisitos:**
- Parte 7 completada (SSH + IP estática)
- Parte 8 completada (Docker + NVIDIA NCT)
- Al menos un motor de inferencia activo (Parte 12/14)
- VSCode instalado en su computadora

**Tiempo estimado de configuración:** 30–45 minutos

**Al final de este capítulo podrá:**
- Desarrollar Python en el Jetson desde VSCode en su PC
- Ejecutar notebooks Jupyter en el Jetson y verlos en su browser
- Instalar PyTorch con soporte CUDA 13.2.1 para JP 7.2
- Llamar a los modelos LLM desde Python (Ollama, vLLM, llama.cpp)
- Aplicar patrones de limpieza de memoria entre experimentos

---

## 17.1 Configurar VSCode Remote SSH

### 17.1.1 Instalar la Extensión Remote SSH en VSCode

En su computadora (Windows/macOS/Linux):

1. Abra **Visual Studio Code**
2. Vaya a **Extensions** (`Ctrl+Shift+X` / `Cmd+Shift+X`)
3. Busque `Remote - SSH` (publicada por Microsoft)
4. Haga clic en **Install**

También instale las extensiones complementarias:
- **Remote - SSH: Editing Configuration Files** (misma colección de Microsoft)
- **Python** (Microsoft) — se instalará automáticamente en el Jetson cuando conecte

### 17.1.2 Configurar el Archivo SSH Config

**En Windows (PowerShell o Notepad):** Edite `C:\Users\<SuUsuario>\.ssh\config`

**En macOS/Linux (terminal):** Edite `~/.ssh/config`

```
# Configuración SSH para el Jetson
Host jetson
    HostName 192.168.1.100
    User jetson
    IdentityFile ~/.ssh/id_jetson
    ServerAliveInterval 60
    ServerAliveCountMax 5
    ForwardAgent yes
```

> Reemplace `192.168.1.100` con la IP estática del Jetson configurada en la Parte 7.

### 17.1.3 Conectar VSCode al Jetson

1. En VSCode, pulse `F1` (o `Ctrl+Shift+P`) para abrir el Command Palette
2. Escriba **Remote-SSH: Connect to Host...**
3. Seleccione `jetson` (aparece gracias al archivo config)
4. Se abre una nueva ventana de VSCode conectada al Jetson
5. En la esquina inferior izquierda verá: **SSH: jetson**

La primera conexión tarda ~1 minuto mientras VSCode instala su servidor en el Jetson. Las siguientes conexiones son inmediatas.

### 17.1.4 Instalar Extensiones Python en el Jetson (desde VSCode)

Con la ventana de VSCode conectada al Jetson:

1. Abra **Extensions** (`Ctrl+Shift+X`)
2. Busque e instale en el Jetson (no en su PC):
   - **Python** (Microsoft)
   - **Jupyter** (Microsoft)
   - **Pylance** (Microsoft)

Estas extensiones se instalan en el Jetson y se ejecutan allí. Su PC solo muestra la interfaz.

---

## 17.2 Crear el Entorno Virtual de Desarrollo

### 17.2.1 Entorno Virtual para Desarrollo Python [VERIFICADO EN JP 7.2]

Abra un terminal integrado en VSCode (`Ctrl+Ñ` o `Ctrl+` ` `): verá una terminal que se ejecuta directamente en el Jetson.

```bash
# Crear el entorno virtual de desarrollo
python3.12 -m venv ~/venvs/dev

# Activar
source ~/venvs/dev/bin/activate

# Verificar Python
python --version
```

```
# Salida esperada
Python 3.12.3
```

```bash
# Instalar dependencias básicas de desarrollo
pip install --upgrade pip wheel setuptools
pip install ipykernel notebook jupyterlab rich requests httpx
```

### 17.2.2 Seleccionar el Intérprete Python en VSCode

1. Pulse `F1` → **Python: Select Interpreter**
2. Seleccione: **Enter interpreter path...**
3. Escriba: `/home/jetson/venvs/dev/bin/python`
4. VSCode ahora usará este entorno por defecto para IntelliSense, debugging y ejecución

---

## 17.3 PyTorch con CUDA 13.2.1 para JetPack 7.2

PyTorch en el Jetson no se instala con el pip normal — el wheel genérico de PyPI está compilado para x86_64. NVIDIA proporciona wheels específicos para JP 7.2.

### 17.3.1 Instalar PyTorch para JP 7.2 [VERIFICADO EN JP 7.2]

```bash
# Activar el venv de desarrollo
source ~/venvs/dev/bin/activate

# Instalar PyTorch desde el índice de paquetes de NVIDIA para Jetson
# (wheel ARM64 + CUDA 13.2.1, compilado para sm_87 = Orin Ampere)
pip install torch torchvision torchaudio \
  --index-url https://pypi.jetson-ai-lab.io/sbsa/cu129

# Alternativamente, desde el repositorio JP 7.2 de NVIDIA:
# pip install torch --index-url https://developer.download.nvidia.com/compute/redist/jp/v72/pytorch/
```

> **NOTA:** El índice `pypi.jetson-ai-lab.io` puede estar sujeto a cambios. Si falla, busque "JetPack 7.2 PyTorch wheel" en la documentación oficial de NVIDIA Jetson AI Lab. La variable CUDA correcta para JP 7.2 es `cu129` (CUDA 12.9/13.x en la nomenclatura de pip).

```bash
# Verificar PyTorch + CUDA
python -c "
import torch
print(f'PyTorch: {torch.__version__}')
print(f'CUDA disponible: {torch.cuda.is_available()}')
print(f'Dispositivo: {torch.cuda.get_device_name(0)}')
print(f'Memoria GPU total: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB')
"
```

```
# Salida esperada
PyTorch: 2.x.x+cu129
CUDA disponible: True
Dispositivo: Orin (nvgpu)
Memoria GPU total: 64.0 GB
```

### 17.3.2 Prueba de Tensor CUDA

```python
# test_cuda.py
import torch

# Crear tensores en GPU
a = torch.randn(1000, 1000).cuda()
b = torch.randn(1000, 1000).cuda()

# Operación en GPU
c = torch.matmul(a, b)

print(f"Tensor en GPU: {c.device}")
print(f"Forma del resultado: {c.shape}")
print(f"Suma: {c.sum().item():.2f}")
print("✅ PyTorch + CUDA funcionando correctamente")
```

```bash
# Ejecutar desde el terminal del Jetson (o con el botón Run en VSCode)
python test_cuda.py
```

```
# Salida esperada
Tensor en GPU: cuda:0
Forma del resultado: torch.Size([1000, 1000])
Suma: 312.45
✅ PyTorch + CUDA funcionando correctamente
```

---

## 17.4 Jupyter Notebooks en el Jetson

Jupyter Notebooks permiten combinar código Python, texto, gráficas y outputs en un solo documento interactivo. Con VSCode Remote SSH puede abrir notebooks en el browser de su PC mientras el código se ejecuta en el Jetson.

### 17.4.1 Iniciar JupyterLab [VERIFICADO EN JP 7.2]

```bash
# En el terminal del Jetson (via VSCode)
source ~/venvs/dev/bin/activate
jupyter lab --no-browser --ip=0.0.0.0 --port=8888 \
  --NotebookApp.token='jetson2024'
```

```
# Salida esperada
[I 2026-06-28 10:00:00.000 ServerApp] Jupyter Server 2.x.x is running at:
[I 2026-06-28 10:00:00.000 ServerApp] http://192.168.1.100:8888/lab?token=jetson2024
[I 2026-06-28 10:00:00.000 ServerApp]     http://127.0.0.1:8888/lab?token=jetson2024
```

Abra en el browser de su PC: `http://192.168.1.100:8888/lab?token=jetson2024`

Verá la interfaz de JupyterLab. El código que ejecute allí corre en el Jetson.

### 17.4.2 Notebooks desde VSCode

VSCode con la extensión Jupyter puede abrir archivos `.ipynb` directamente:

1. En VSCode Remote (conectado al Jetson), cree un nuevo archivo `experimento.ipynb`
2. Seleccione el kernel: **Python 3 (~/venvs/dev)** o el que creó
3. Ejecute celdas normalmente con `Shift+Enter`

El código corre en el Jetson pero la interfaz aparece en su PC.

---

## 17.5 Experimento 1 — Llamar a Ollama desde Python

Este experimento conecta Python con el servidor Ollama local (instalado en la Parte 12) usando la API compatible con OpenAI.

### 17.5.1 Prerrequisitos de Memoria

Antes de iniciar este experimento, verifique el estado del sistema:

```bash
# En terminal del Jetson
free -h | awk '/^Mem:/{printf "RAM: %s usados de %s, %s libres\n", $3, $2, $7}'
motors-status   # alias de Parte 15
```

Si Ollama no está activo, inícielo:

```bash
ollama-start    # alias de Parte 12, o:
sudo systemctl start ollama
```

### 17.5.2 Cliente Python con SDK de OpenAI [VERIFICADO EN JP 7.2]

```bash
# Instalar el SDK de OpenAI (compatible con Ollama, vLLM y llama.cpp)
pip install openai
```

```python
# experimento_1_ollama.py
from openai import OpenAI

# Ollama expone una API compatible con OpenAI en el puerto 11434
client = OpenAI(
    base_url="http://localhost:11434/v1",
    api_key="ollama"  # Ollama no requiere clave real
)

# Listar modelos disponibles
modelos = client.models.list()
print("Modelos Ollama disponibles:")
for m in modelos.data:
    print(f"  - {m.id}")

# Generar una respuesta
respuesta = client.chat.completions.create(
    model="qwen3:7b",  # usar un modelo instalado en la Parte 12
    messages=[
        {"role": "system", "content": "Eres un experto en IA y computación embebida."},
        {"role": "user", "content": "¿Qué ventajas tiene la memoria unificada del Jetson para la inferencia de LLMs?"}
    ],
    max_tokens=300
)

print("\n── Respuesta ──")
print(respuesta.choices[0].message.content)
print(f"\n── Tokens ──")
print(f"  Prompt: {respuesta.usage.prompt_tokens}")
print(f"  Completion: {respuesta.usage.completion_tokens}")
print(f"  Total: {respuesta.usage.total_tokens}")
```

```
# Salida esperada
Modelos Ollama disponibles:
  - qwen3:7b
  - deepseek-r1:7b
  - ...

── Respuesta ──
La memoria unificada del Jetson AGX Orin ofrece varias ventajas clave para la inferencia de LLMs:

1. **Sin cuello de botella PCIe**: En una GPU discreta, los datos deben transferirse entre la RAM del sistema y la VRAM de la GPU a través del bus PCIe, lo que limita el ancho de banda...

── Tokens ──
  Prompt: 45
  Completion: 287
  Total: 332
```

### 17.5.3 Streaming de Tokens en Tiempo Real

```python
# experimento_1b_streaming.py
from openai import OpenAI

client = OpenAI(base_url="http://localhost:11434/v1", api_key="ollama")

print("Respuesta en streaming (token por token):\n")

# stream=True activa el modo streaming
stream = client.chat.completions.create(
    model="qwen3:7b",
    messages=[{"role": "user", "content": "Explica qué es CUDA en 3 oraciones."}],
    max_tokens=150,
    stream=True
)

for chunk in stream:
    if chunk.choices[0].delta.content is not None:
        print(chunk.choices[0].delta.content, end="", flush=True)

print("\n\n✅ Streaming completado")
```

---

## 17.6 Experimento 2 — Llamar a vLLM desde Python

vLLM expone exactamente la misma API que OpenAI, con el mismo SDK. Solo cambia el `base_url` y el nombre del modelo.

### 17.6.1 Prerrequisitos de Memoria

```bash
# Lanzar vLLM si no está activo (alias de Parte 15)
start-qwen35    # lanza el modelo 35B de Parte 14
# o start-qwen4b para el modelo de 4B (más rápido, usa menos RAM)
```

### 17.6.2 Cliente Python para vLLM [VERIFICADO EN JP 7.2]

```python
# experimento_2_vllm.py
from openai import OpenAI
import time

# vLLM en el puerto 8000 — misma API que OpenAI
client = OpenAI(
    base_url="http://localhost:8000/v1",
    api_key="not-needed"  # vLLM no requiere clave por defecto
)

# Verificar qué modelo está activo
modelos = client.models.list()
modelo_activo = modelos.data[0].id
print(f"Modelo activo en vLLM: {modelo_activo}")

# Benchmark: medir tokens por segundo
inicio = time.time()

respuesta = client.chat.completions.create(
    model=modelo_activo,
    messages=[
        {"role": "user", "content": "Escribe un análisis de 200 palabras sobre las ventajas del edge computing."}
    ],
    max_tokens=300
)

duracion = time.time() - inicio
tokens_salida = respuesta.usage.completion_tokens
tps = tokens_salida / duracion

print(f"\n── Rendimiento ──")
print(f"  Tokens generados: {tokens_salida}")
print(f"  Tiempo total: {duracion:.2f} seg")
print(f"  Velocidad: {tps:.1f} tok/s")
print(f"\n── Respuesta ──")
print(respuesta.choices[0].message.content)
```

### 17.6.3 Comparar Velocidad entre Motores

```python
# experimento_2b_benchmark.py
from openai import OpenAI
import time

PREGUNTA = "¿Qué es un transformer en el contexto de inteligencia artificial? Responde en 2 oraciones."
MAX_TOKENS = 100

def medir_velocidad(nombre, url, modelo, api_key="no-key"):
    try:
        client = OpenAI(base_url=url, api_key=api_key)
        inicio = time.time()
        r = client.chat.completions.create(
            model=modelo,
            messages=[{"role": "user", "content": PREGUNTA}],
            max_tokens=MAX_TOKENS
        )
        dt = time.time() - inicio
        tps = r.usage.completion_tokens / dt
        return f"  ✅ {nombre}: {tps:.1f} tok/s ({r.usage.completion_tokens} tokens en {dt:.1f}s)"
    except Exception as e:
        return f"  ⚠️  {nombre}: no disponible ({str(e)[:50]})"

print("═══ Benchmark de motores de inferencia ═══")
# Ajuste los nombres de modelos según los que tenga instalados
print(medir_velocidad("Ollama qwen3:7b", "http://localhost:11434/v1", "qwen3:7b", "ollama"))
print(medir_velocidad("vLLM qwen35",     "http://localhost:8000/v1",  "qwen35"))
print(medir_velocidad("llama.cpp",        "http://localhost:8080/v1",  "nemotron-omni"))
print("═══════════════════════════════════════════")
```

---

## 17.7 Experimento 3 — Hugging Face Transformers Directo (sin contenedor)

Para modelos pequeños (≤3B parámetros), puede cargarlos directamente en Python usando la librería `transformers` de Hugging Face, sin necesidad de contenedores ni servidores HTTP.

### 17.7.1 Instalar Transformers [VERIFICADO EN JP 7.2]

```bash
# En el venv de desarrollo
pip install transformers accelerate sentencepiece
```

### 17.7.2 Cargar un Modelo Pequeño Directamente

```python
# experimento_3_transformers.py
import torch
from transformers import pipeline

print(f"CUDA disponible: {torch.cuda.is_available()}")
print(f"Cargando modelo... (primera vez descarga ~1-2 GB)")

# Cargar un modelo pequeño directamente en GPU
# phi-2 es un buen ejemplo: 2.7B parámetros, ~5GB con float16
pipe = pipeline(
    "text-generation",
    model="microsoft/phi-2",
    device=0,              # GPU 0 (la GPU del Jetson)
    torch_dtype=torch.float16  # float16 reduce a la mitad el uso de RAM
)

print("✅ Modelo cargado\n")

# Generar respuesta
resultado = pipe(
    "Explain what a neural network is in simple terms:",
    max_new_tokens=100,
    do_sample=False
)

print(resultado[0]["generated_text"])
```

### 17.7.3 Limpieza de Memoria tras el Experimento

```python
# Siempre liberar memoria GPU después de terminar con un modelo directo
import gc
import torch

# Eliminar el pipeline y el modelo de la GPU
del pipe
gc.collect()
torch.cuda.empty_cache()

# Verificar liberación
print(f"Memoria GPU reservada: {torch.cuda.memory_reserved(0) / 1e9:.2f} GB")
print(f"Memoria GPU asignada: {torch.cuda.memory_allocated(0) / 1e9:.2f} GB")
print("✅ Memoria GPU liberada")
```

```
# Salida esperada
Memoria GPU reservada: 0.00 GB
Memoria GPU asignada: 0.00 GB
✅ Memoria GPU liberada
```

> **IMPORTANTE:** Si no ejecuta la limpieza y luego intenta arrancar un contenedor vLLM o llama.cpp, el modelo Hugging Face sigue ocupando RAM en la GPU y puede causar OOM. Siempre limpie antes de cambiar de motor.

---

## 17.8 Patrón de Desarrollo Recomendado

El flujo de trabajo eficiente para desarrollar con LLMs en el Jetson sigue este ciclo:

```
┌──────────────────────────────────────────────────────────────┐
│  CICLO DE DESARROLLO EN JETSON (desde VSCode Remote SSH)     │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  1. Verificar estado inicial                                  │
│     motors-status / check-ready / free -h                   │
│                                                              │
│  2. Lanzar motor necesario                                   │
│     start-qwen35 / start-nemotron / sudo systemctl start ollama │
│                                                              │
│  3. Desarrollar y experimentar                               │
│     (VSCode + notebook Jupyter + Python scripts)             │
│                                                              │
│  4. Terminar experimento y limpiar                           │
│     kill-qwen35 / del modelo; gc.collect(); empty_cache()   │
│                                                              │
│  5. Verificar que la memoria quedó libre                     │
│     free -h / motors-status                                  │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

### 17.8.1 Script de Verificación Pre-Experimento [VERIFICADO EN JP 7.2]

```python
# utils/pre_check.py — ejecutar al inicio de cada notebook
import subprocess
import psutil

def check_system():
    """Verifica que el sistema está listo para experimentar."""
    mem = psutil.virtual_memory()
    libres_gb = mem.available / 1e9
    total_gb = mem.total / 1e9
    uso_pct = mem.percent
    
    print(f"═══ Estado del Sistema ═══")
    print(f"RAM: {libres_gb:.1f} GB libres de {total_gb:.1f} GB ({uso_pct:.0f}% usado)")
    
    if libres_gb < 20:
        print("⚠️  Menos de 20 GB libres — considere ejecutar jetson-clean antes")
    else:
        print(f"✅ Sistema listo ({libres_gb:.0f} GB disponibles)")
    
    # Verificar endpoints activos
    import requests
    endpoints = [
        ("Ollama", "http://localhost:11434/api/version"),
        ("vLLM", "http://localhost:8000/v1/models"),
        ("llama.cpp", "http://localhost:8080/v1/models"),
    ]
    print("\n─── Motores activos ───")
    for nombre, url in endpoints:
        try:
            r = requests.get(url, timeout=2)
            if r.status_code == 200:
                print(f"  ✅ {nombre}")
        except:
            print(f"  ○  {nombre} → offline")
    print("══════════════════════════")

check_system()
```

```bash
# Instalar psutil
pip install psutil
```

---

## 17.9 Limpieza Post-Experimento

```bash
# Limpieza completa después de una sesión de desarrollo [VERIFICADO EN JP 7.2]
# Ejecutar en el terminal del Jetson (no en Python)

# 1. Detener motores activos
kill-qwen35 2>/dev/null || true
kill-nemotron 2>/dev/null || true
kill-qwen4b 2>/dev/null || true
sudo systemctl stop ollama 2>/dev/null || true

# 2. Limpiar caché del sistema
sync && echo 3 | sudo tee /proc/sys/vm/drop_caches > /dev/null

# 3. Verificar estado final
echo "Estado post-limpieza:"
free -h | awk '/^Mem:/{printf "RAM: %s usados de %s, %s libres\n", $3, $2, $7}'
motors-status

# 4. Bajar a modo bajo consumo
pwr-15w
```

---

## 17.10 Verificación Final del Capítulo

```bash
# Verificación de configuración de desarrollo [VERIFICADO EN JP 7.2]
echo "╔══════════════════════════════════════════════════════╗"
echo "║    VERIFICACIÓN PARTE 17 — ENTORNO DE DESARROLLO    ║"
echo "╚══════════════════════════════════════════════════════╝"

echo ""
echo "── Entorno virtual ──"
source ~/venvs/dev/bin/activate
python --version | grep -q "3.12" \
  && echo "  ✅ Python 3.12 activo" \
  || echo "  ⚠️  Verificar versión de Python"

echo ""
echo "── PyTorch + CUDA ──"
python -c "
import torch
if torch.cuda.is_available():
    print(f'  ✅ PyTorch {torch.__version__} con CUDA {torch.version.cuda}')
    print(f'  ✅ GPU: {torch.cuda.get_device_name(0)}')
    print(f'  ✅ Memoria GPU: {torch.cuda.get_device_properties(0).total_memory/1e9:.0f} GB')
else:
    print('  ⚠️  CUDA no disponible — revisar instalación de PyTorch para JP 7.2')
" 2>/dev/null

echo ""
echo "── Librerías de desarrollo ──"
python -c "
import importlib
libs = ['openai', 'requests', 'httpx', 'jupyter', 'notebook']
for lib in libs:
    try:
        importlib.import_module(lib)
        print(f'  ✅ {lib}')
    except ImportError:
        print(f'  ○  {lib} → no instalado (pip install {lib})')
"

echo ""
echo "════════════════════════════════════════════════════"
```

```
# Salida esperada
── Entorno virtual ──
  ✅ Python 3.12 activo

── PyTorch + CUDA ──
  ✅ PyTorch 2.x.x con CUDA 12.9
  ✅ GPU: Orin (nvgpu)
  ✅ Memoria GPU: 64 GB

── Librerías de desarrollo ──
  ✅ openai
  ✅ requests
  ✅ httpx
  ✅ jupyter
  ✅ notebook
```

> **Próximo paso:** La Parte 18 cubre en profundidad el ecosistema jetson-containers — las 51 imágenes Docker optimizadas para Jetson que serán la base de todos los proyectos de la Fase 2.
