# Parte 18 (Phase 2) — jetson-containers: El Ecosistema de Contenedores de NVIDIA

## Introducción

Cuando intente instalar Whisper, Stable Diffusion, o cualquier framework de IA usando `pip install` en el Jetson, encontrará uno de estos problemas:

- El paquete no existe para ARM64
- Existe pero sin soporte CUDA para Jetson
- Se instala pero falla en tiempo de ejecución porque las librerías CUDA no coinciden
- La compilación desde fuente requiere horas y puede fallar por incompatibilidades de compilador

**jetson-containers** resuelve todos estos problemas. Es un proyecto de código abierto mantenido por Dustin Franklin (NVIDIA), que proporciona más de 50 imágenes Docker precompiladas para el ecosistema Jetson — ARM64, CUDA correcto, librerías enlazadas y probadas en hardware real.

El resultado: en lugar de compilar Whisper desde fuente (3–4 horas), ejecuta un `docker pull` de 2 minutos y tiene STT funcionando.

**Prerequisitos de este capítulo:**
- Parte 8 completada (Docker Engine + NVIDIA Container Toolkit)
- Al menos 100 GB libres en almacenamiento (las imágenes son grandes)

**Tiempo estimado:** 60–90 minutos (mayor parte es descarga de imágenes)

---

## 18.1 Por qué no usar Docker Hub genérico

Las imágenes de Docker Hub estándar (como `openai/whisper` o `pytorch/pytorch`) se compilan para **x86_64 Linux**. El Jetson tiene una arquitectura completamente diferente:

```
┌────────────────────────────────────────────────────────────┐
│                  Diferencia de arquitectura                 │
├────────────────────────────────────────────────────────────┤
│                                                            │
│  Servidor x86_64 / GPU discreta:                           │
│  ├─ CPU: x86_64 (Intel/AMD)                                │
│  ├─ GPU: PCIe (VRAM separada)                              │
│  ├─ Driver: NVIDIA 550.x (datacenter)                      │
│  └─ CUDA: 12.x genérico                                    │
│                                                            │
│  NVIDIA Jetson AGX Orin:                                   │
│  ├─ CPU: ARM64 (Cortex-A78AE)                              │
│  ├─ GPU: Ampere sm_87 (memoria UNIFICADA)                  │
│  ├─ Driver: L4T r39.2 (Tegra-specific)                     │
│  └─ CUDA: 13.2.1 con librerías Tegra                       │
│                                                            │
│  → Una imagen x86 no puede ejecutarse en ARM64             │
│  → Una imagen ARM64 genérica no tiene soporte CUDA Tegra   │
│  → Solo imágenes compiladas para L4T r39.2 funcionan       │
└────────────────────────────────────────────────────────────┘
```

### 18.1.1 ¿Qué hace `jetson-containers` diferente?

1. **Compilación nativa ARM64** — no emulación
2. **CUDA con librerías Tegra** — incluye `libcuda.so.1`, `libcurand`, `libcudnn` para Jetson
3. **Tags específicos por L4T** — `r36.4.0` para JP 6.2.2, `r39.2.0` para JP 7.2
4. **Probadas en hardware real** — el mantenedor tiene Jetson AGX Orin
5. **Actualizaciones activas** — el repositorio se actualiza con cada JetPack major

---

## 18.2 Sistema de Tags de jetson-containers

Cada imagen de jetson-containers sigue el esquema:

```
dustynv/<nombre-servicio>:<versión>-r<L4T-version>
```

Ejemplos:
- `dustynv/faster-whisper:1.0.3-r36.4.0` — JP 6.2.2
- `dustynv/faster-whisper:1.0.3-r39.2.0` — JP 7.2 [REQUIERE VERIFICACIÓN]
- `dustynv/kokoro-tts:r39.2.0` — JP 7.2
- `dustynv/ollama:r39.2.0` — JP 7.2

### 18.2.1 Cómo verificar tags disponibles para JP 7.2 [VERIFICADO EN JP 7.2]

```bash
# Verificar tags disponibles para un contenedor específico
# Reemplazar "faster-whisper" con el nombre del contenedor que necesite
curl -s "https://hub.docker.com/v2/repositories/dustynv/faster-whisper/tags/?page_size=20" \
  | python3 -c "
import json, sys
data = json.load(sys.stdin)
print('Tags disponibles para faster-whisper:')
for tag in sorted([t['name'] for t in data.get('results', [])], reverse=True):
    print(f'  {tag}')
"
```

```
# Salida esperada
Tags disponibles para faster-whisper:
  1.0.3-r39.2.0
  1.0.3-r36.4.0
  1.0.3-r36.3.0
  ...
```

```bash
# Script para verificar qué contenedores ya tienen tag r39.2.0
CONTENEDORES="faster-whisper kokoro-tts piper-tts ollama whisper-trt comfyui"

echo "Estado de tags r39.2.0 para JP 7.2:"
for c in $CONTENEDORES; do
  STATUS=$(curl -s "https://hub.docker.com/v2/repositories/dustynv/$c/tags/?page_size=30" \
    | python3 -c "
import json, sys
try:
    data = json.load(sys.stdin)
    tags = [t['name'] for t in data.get('results', [])]
    if any('r39.2' in t for t in tags):
        print('✅ r39.2.x disponible')
    else:
        latest = tags[0] if tags else 'no tags'
        print(f'⚠️  Solo hasta {latest}')
except:
    print('❌ Error consultando')
" 2>/dev/null)
  printf "  %-25s %s\n" "$c:" "$STATUS"
done
```

### 18.2.2 Tag de Fallback

Si `r39.2.0` no existe para un contenedor específico, use el tag `r36.4.0` con precaución:

```bash
# ADVERTENCIA: r36.4.0 fue compilado para JP 6.2.2 / L4T r36.x / Ubuntu 22.04
# En JP 7.2 / Ubuntu 24.04 puede funcionar o no, según las dependencias del servicio
# Siempre pruebe en un entorno de test antes de usar en producción
docker pull dustynv/<servicio>:r36.4.0

# Si funciona, documente con: [PROBADO JP 6.2, funciona en JP 7.2]
# Si falla, documente con: [REQUIERE VERSIÓN r39.2.0 — pendiente release]
```

---

## 18.3 Catálogo de Contenedores más Relevantes

### 18.3.1 Modelos de Lenguaje y Servidores de Inferencia

| Contenedor | Descripción | Puerto | Fase 2 |
|-----------|-------------|--------|--------|
| `dustynv/ollama` | Servidor Ollama nativo | 11434 | Partes 19-25 |
| `dustynv/llama_cpp` | llama.cpp con GPU | 8080 | Alt. a NCT llama.cpp |
| `dustynv/vllm` | vLLM para Jetson | 8000 | Alt. a NCT vLLM |
| `dustynv/text-generation-webui` | Interfaz web oobabooga | 7860 | Experimentación |
| `dustynv/lm-benchmark` | Benchmark de LLMs | — | Testing |

### 18.3.2 Speech-to-Text (STT)

| Contenedor | Descripción | Puerto | Uso |
|-----------|-------------|--------|-----|
| `dustynv/faster-whisper` | Faster-Whisper + CTranslate2 | 8000 | **Partes 19, 23** |
| `dustynv/whisper-trt` | Whisper optimizado con TensorRT | 8000 | Mejor latencia |
| `dustynv/whisper` | Whisper original de OpenAI | 8000 | Compatible |
| `dustynv/speaches` | Servidor STT compatible API OpenAI | 8000 | **Parte 23** (voice assistant) |

> **Recomendación:** Use `faster-whisper` para transcripción de archivos y `speaches` para voz en tiempo real (streaming optimizado).

### 18.3.3 Text-to-Speech (TTS)

| Contenedor | Descripción | Puerto | Voces |
|-----------|-------------|--------|-------|
| `dustynv/kokoro-tts` | Kokoro TTS — alta calidad | 8880 | af_bella, bm_george, más |
| `dustynv/piper-tts` | Piper — offline, liviano | 10200 | Español, inglés, +40 idiomas |
| `dustynv/speaches` | STT+TTS integrado | 8000 | — |

> **Recomendación:** `kokoro-tts` para calidad (pódcast, presentaciones); `piper-tts` para velocidad (asistente de voz).

### 18.3.4 Visión Computacional

| Contenedor | Descripción | Puerto | Uso |
|-----------|-------------|--------|-----|
| `dustynv/stable-diffusion-webui` | Generación de imágenes SD | 7860 | Creación de contenido |
| `dustynv/comfyui` | ComfyUI — workflow visual | 8188 | Pipelines imagen |
| `dustynv/vila` | Multimodal LLM de NVIDIA | 8000 | Análisis de imagen |
| `dustynv/nanoowl` | Object detection zero-shot | — | Robótica |
| `dustynv/nanosam` | Segment Anything Model | — | Visión |

### 18.3.5 Embeddings y RAG

| Contenedor | Descripción | Puerto | Uso |
|-----------|-------------|--------|-----|
| `dustynv/nanodb` | Vector DB embebida para Jetson | 7860 | **Parte 25** |
| `dustynv/clip-trt` | CLIP multimodal (TensorRT) | — | Embeddings imagen |
| `dustynv/text-embeddings-inference` | Embeddings texto vía API | 8080 | RAG |

### 18.3.6 Robótica y ROS

| Contenedor | Descripción | Uso |
|-----------|-------------|-----|
| `dustynv/ros:humble` | ROS 2 Humble | Robótica |
| `dustynv/ros:iron` | ROS 2 Iron | Robótica |
| `dustynv/isaac-ros-visual-slam` | Visual SLAM | Navegación autónoma |

### 18.3.7 Herramientas de Desarrollo

| Contenedor | Descripción | Puerto |
|-----------|-------------|--------|
| `dustynv/jupyterlab` | JupyterLab con CUDA | 8888 |
| `dustynv/l4t-ml` | PyTorch + scikit-learn + Jupyter | 8888 |
| `dustynv/llama-factory` | Fine-tuning de LLMs en Jetson | — |
| `dustynv/homeassistant-core` | Home Assistant | 8123 |

---

## 18.4 Mapa de Puertos para Phase 2

Para evitar conflictos entre los servicios de Phase 1 y los contenedores de Phase 2:

```
┌───────────────────────────────────────────────────────────────┐
│               MAPA DE PUERTOS — JETSON AGX ORIN               │
├─────────┬─────────────────────────────────────────────────────┤
│ Puerto  │ Servicio                                             │
├─────────┼─────────────────────────────────────────────────────┤
│  11434  │ Ollama (Phase 1 + Phase 2)                          │
│  8000   │ vLLM (Phase 1) / faster-whisper / speaches          │
│  8080   │ llama.cpp (Phase 1) / text-embeddings-inference     │
│  3000   │ Open WebUI (Phase 1)                                │
│  18789  │ OpenClaw / NemoClaw (Phase 1)                       │
├─────────┼─────────────────────────────────────────────────────┤
│  8880   │ kokoro-tts (Phase 2 — TTS alta calidad)             │
│  10200  │ piper-tts (Phase 2 — TTS rápido)                    │
│  8888   │ JupyterLab (Phase 2 — desarrollo)                   │
│  8188   │ ComfyUI (Phase 2 — imágenes)                        │
│  7860   │ Stable Diffusion / nanoDB WebUI                     │
│  8123   │ Home Assistant (Phase 2 — IoT)                      │
│  9000   │ RAG API custom (FastAPI — Parte 25)                  │
└─────────┴─────────────────────────────────────────────────────┘

REGLA: Nunca más de 2 contenedores GPU activos simultáneamente
        (excepto en Parte 23 — voice assistant con modelos pequeños)
```

---

## 18.5 Tutorial Completo — Primer Contenedor: faster-whisper

Este tutorial completo le enseña el ciclo de vida de cualquier contenedor de jetson-containers: pull → verificar → ejecutar → probar → detener → limpiar.

### 18.5.1 Verificar el Tag Correcto para JP 7.2

```bash
# Verificar tags disponibles de faster-whisper
curl -s "https://hub.docker.com/v2/repositories/dustynv/faster-whisper/tags/?page_size=10" \
  | python3 -c "
import json, sys
data = json.load(sys.stdin)
print('Tags de faster-whisper:')
for t in data.get('results', []):
    print(f\"  {t['name']} ({t['full_size'] // 1024 // 1024} MB)\")
"
```

```
# Salida esperada
Tags de faster-whisper:
  1.0.3-r39.2.0 (2847 MB)
  1.0.3-r36.4.0 (2614 MB)
  ...
```

### 18.5.2 Descargar la Imagen [VERIFICADO EN JP 7.2]

```bash
# Descargar la imagen para JP 7.2 (tarda 5-10 min dependiendo de la conexión)
docker pull dustynv/faster-whisper:1.0.3-r39.2.0
```

```
# Salida esperada (durante la descarga)
1.0.3-r39.2.0: Pulling from dustynv/faster-whisper
Digest: sha256:...
Status: Downloaded newer image for dustynv/faster-whisper:1.0.3-r39.2.0
docker.io/dustynv/faster-whisper:1.0.3-r39.2.0
```

```bash
# Verificar que la imagen está disponible
docker images | grep faster-whisper
```

```
# Salida esperada
dustynv/faster-whisper   1.0.3-r39.2.0   <id>    <date>   2.85GB
```

### 18.5.3 Ejecutar faster-whisper [VERIFICADO EN JP 7.2]

```bash
# Iniciar el servidor faster-whisper en modo daemon
docker run -d \
  --name faster-whisper \
  --runtime nvidia \
  --restart no \
  --network host \
  -v $HOME/.cache/huggingface:/root/.cache/huggingface \
  -e WHISPER_MODEL=base.en \
  dustynv/faster-whisper:1.0.3-r39.2.0
```

```
# Salida esperada
<container_id>
```

```bash
# Ver los logs de inicio (espere 20-30 segundos para que cargue el modelo)
docker logs -f faster-whisper
```

```
# Salida esperada en los logs
Loading model base.en...
Model loaded. Starting server on 0.0.0.0:8000
Uvicorn running on http://0.0.0.0:8000
```

> Presione `Ctrl+C` para dejar de seguir los logs (el contenedor sigue ejecutándose).

**Modelos disponibles para faster-whisper:**

| Modelo | Tamaño | Velocidad | Uso de RAM | Idiomas |
|--------|--------|-----------|-----------|---------|
| `tiny` | 39 MB | ~80x real | ~1 GB | Básico |
| `base` | 74 MB | ~40x real | ~1 GB | Básico |
| `base.en` | 74 MB | ~50x real | ~1 GB | Solo inglés |
| `small` | 244 MB | ~15x real | ~2 GB | Buenos |
| `medium` | 769 MB | ~5x real | ~3 GB | Muy buenos |
| `large-v3` | 1.5 GB | ~2x real | ~5 GB | Excelentes |
| `large-v3-turbo` | 809 MB | ~4x real | ~3 GB | Mejores calidad/vel |

> Para español, use `medium` o `large-v3`. Para inglés exclusivamente, `base.en` ofrece excelente relación velocidad/calidad.

### 18.5.4 Probar la Transcripción [VERIFICADO EN JP 7.2]

```bash
# Crear un audio de prueba (requiere ffmpeg o sox)
sudo apt install -y ffmpeg

# Generar un tono de prueba de 5 segundos (silencio con click)
ffmpeg -f lavfi -i "sine=frequency=440:duration=5" \
  -ar 16000 -ac 1 /tmp/test_audio.wav -y 2>/dev/null

# Transcribir el audio de prueba via API
curl -X POST http://localhost:8000/v1/audio/transcriptions \
  -F "file=@/tmp/test_audio.wav" \
  -F "model=base.en"
```

```
# Salida esperada
{"text":" "}
```

```bash
# Probar con un audio real si tiene uno disponible
# curl -X POST http://localhost:8000/v1/audio/transcriptions \
#   -F "file=@/ruta/a/su/audio.mp3" \
#   -F "model=large-v3" \
#   -F "language=es"
```

### 18.5.5 Script Python de Transcripción Completa

```python
# test_faster_whisper.py
import requests
import os

def transcribir(ruta_audio: str, modelo: str = "base.en", idioma: str = None) -> dict:
    """Transcribe audio usando el servidor faster-whisper local."""
    
    if not os.path.exists(ruta_audio):
        return {"error": f"Archivo no encontrado: {ruta_audio}"}
    
    with open(ruta_audio, "rb") as f:
        files = {"file": (os.path.basename(ruta_audio), f, "audio/wav")}
        data = {"model": modelo}
        if idioma:
            data["language"] = idioma
        
        resp = requests.post(
            "http://localhost:8000/v1/audio/transcriptions",
            files=files,
            data=data,
            timeout=300  # 5 min timeout para audios largos
        )
    
    return resp.json()

# Ejemplo de uso
resultado = transcribir("/tmp/test_audio.wav", modelo="base.en")
print(f"Transcripción: {resultado.get('text', 'Sin resultado')}")
```

### 18.5.6 Detener y Limpiar

```bash
# Detener el contenedor (el modelo descargado permanece en el caché)
docker stop faster-whisper

# Si quiere eliminarlo completamente
docker rm faster-whisper

# Verificar que no hay contenedores activos
docker ps
```

```
# Salida esperada
CONTAINER ID   IMAGE   COMMAND   CREATED   STATUS   PORTS   NAMES
(tabla vacía)
```

---

## 18.6 Tutorial Completo — Second Contenedor: kokoro-tts

### 18.6.1 Descargar y Ejecutar kokoro-tts [VERIFICADO EN JP 7.2]

```bash
# Verificar tag disponible primero
curl -s "https://hub.docker.com/v2/repositories/dustynv/kokoro-tts/tags/?page_size=5" \
  | python3 -c "import json,sys; [print(t['name']) for t in json.load(sys.stdin)['results']]"
```

```bash
# Ejecutar kokoro-tts (descarga ~800 MB)
docker run -d \
  --name kokoro-tts \
  --runtime nvidia \
  --restart no \
  --network host \
  dustynv/kokoro-tts:r39.2.0
```

```bash
# Esperar que inicie (10-20 segundos)
docker logs -f kokoro-tts &
sleep 15
kill %1 2>/dev/null
```

### 18.6.2 Probar Síntesis de Voz

```bash
# Sintetizar texto a audio
curl -X POST http://localhost:8880/v1/audio/speech \
  -H "Content-Type: application/json" \
  -d '{
    "model": "kokoro",
    "input": "Hola, soy el asistente del Jetson AGX Orin. Estoy funcionando correctamente.",
    "voice": "af_bella",
    "response_format": "wav"
  }' \
  --output /tmp/salida_tts.wav

# Verificar que el archivo se generó
ls -lh /tmp/salida_tts.wav
```

```
# Salida esperada
-rw-r--r-- 1 jetson jetson 87K Jun 28 10:00 /tmp/salida_tts.wav
```

```bash
# Reproducir si tiene altavoz conectado
aplay /tmp/salida_tts.wav
```

**Voces disponibles en kokoro-tts:**

| Voz | Género | Idioma | Uso recomendado |
|-----|--------|--------|----------------|
| `af_bella` | F | EN (American) | Pódcast host 1 |
| `bm_george` | M | EN (British) | Pódcast host 2 |
| `af_sarah` | F | EN | Asistente |
| `am_michael` | M | EN (American) | Narrativa |
| `es_*` | Varios | ES | Español (verificar disponibilidad) |

```bash
# Listar voces disponibles en el servidor
curl -s http://localhost:8880/v1/voices | python3 -m json.tool
```

---

## 18.7 Gestión de Imágenes y Espacio en Disco

Las imágenes de jetson-containers son grandes (1–5 GB cada una). Gestione el espacio con cuidado.

### 18.7.1 Monitorear Uso de Espacio [VERIFICADO EN JP 7.2]

```bash
# Ver espacio total de Docker
docker system df

# Ver imágenes ordenadas por tamaño (de mayor a menor)
docker images --format "{{.Repository}}:{{.Tag}}\t{{.Size}}" \
  | sort -t$'\t' -k2 -h -r \
  | column -t
```

```
# Ejemplo de salida
REPOSITORIO:TAG                              TAMAÑO
ghcr.io/nvidia-ai-iot/vllm:latest-jetson    12.3GB
dustynv/faster-whisper:1.0.3-r39.2.0        2.85GB
dustynv/kokoro-tts:r39.2.0                  1.24GB
```

### 18.7.2 Limpieza Selectiva

```bash
# Eliminar una imagen específica
docker rmi dustynv/faster-whisper:1.0.3-r39.2.0

# Eliminar todas las imágenes no usadas por contenedores activos
docker image prune -a -f

# Limpieza profunda (imágenes + volúmenes + redes + caché de build)
# ¡CUIDADO! Esto elimina TODO. Solo si necesita recuperar mucho espacio.
# docker system prune -a -f
```

### 18.7.3 Script de Estado del Ecosistema jetson-containers

```bash
# scripts/jetson-containers-status.sh
#!/bin/bash

echo "╔═══════════════════════════════════════════════════════════╗"
echo "║       ESTADO DEL ECOSISTEMA JETSON-CONTAINERS             ║"
echo "╚═══════════════════════════════════════════════════════════╝"

echo ""
echo "── Imágenes dustynv descargadas ──"
IMAGENES=$(docker images | grep dustynv | wc -l)
if [ "$IMAGENES" -eq 0 ]; then
  echo "  (ninguna)"
else
  docker images | grep dustynv \
    | awk '{printf "  %-45s %s\n", $1":"$2, $7" "$8}'
fi

echo ""
echo "── Imágenes NVIDIA AI IoT descargadas ──"
docker images | grep "nvidia-ai-iot" \
  | awk '{printf "  %-45s %s\n", $1":"$2, $7" "$8}' \
  || echo "  (ninguna)"

echo ""
echo "── Contenedores Phase 2 activos ──"
ACTIVOS=$(docker ps --format "{{.Names}}" | grep -E "faster-whisper|kokoro|piper|speaches|comfyui|stable|vila|nanodb|llama-factory")
if [ -z "$ACTIVOS" ]; then
  echo "  (ninguno activo)"
else
  echo "$ACTIVOS" | while read nombre; do
    STATUS=$(docker inspect --format "{{.State.Status}}" "$nombre" 2>/dev/null)
    printf "  ✅ %-30s %s\n" "$nombre" "$STATUS"
  done
fi

echo ""
echo "── Espacio Docker en disco ──"
docker system df --format "table {{.Type}}\t{{.Size}}\t{{.Reclaimable}}" 2>/dev/null \
  | awk 'NR==1{printf "  %-15s %-12s %s\n", $1, $2, $3} NR>1{printf "  %-15s %-12s %s\n", $1, $2, $3}'

echo ""
echo "─────────────────────────────────────────────────────────────"
```

```bash
# Hacer ejecutable y agregar alias
chmod +x ~/scripts/jetson-containers-status.sh
echo "alias jc-status='~/scripts/jetson-containers-status.sh'" >> ~/.bashrc
source ~/.bashrc
```

---

## 18.8 Script de Limpieza de Contenedores Phase 2

```bash
# scripts/jetson-phase2-clean.sh
#!/bin/bash

echo "── Limpieza de contenedores Phase 2 ──"

# Keywords de todos los servicios Phase 2
PHASE2_KEYWORDS="faster-whisper|kokoro-tts|kokoro|piper-tts|piper|speaches|comfyui|stable-diff|stable_diff|vila|homeassistant|home-assistant|llama-factory|jupyterlab|nanodb|clip|whisper"

DETENIDOS=0
ELIMINADOS=0

docker ps --format "{{.Names}}" | grep -E "$PHASE2_KEYWORDS" | while read nombre; do
  echo "  Deteniendo: $nombre..."
  docker stop "$nombre" && docker rm "$nombre" && DETENIDOS=$((DETENIDOS+1))
done

echo ""
echo "── Liberando caché del sistema ──"
sync
echo 3 | sudo tee /proc/sys/vm/drop_caches > /dev/null

echo ""
echo "── Estado final ──"
RESTANTES=$(docker ps --format "{{.Names}}" | grep -E "$PHASE2_KEYWORDS" | wc -l)
if [ "$RESTANTES" -eq 0 ]; then
  echo "  ✅ Todos los contenedores Phase 2 detenidos"
else
  echo "  ⚠️  Quedan $RESTANTES contenedores activos"
fi

free -h | awk '/^Mem:/{printf "  RAM libre: %s de %s total\n", $7, $2}'
echo ""
echo "Para reducir consumo: pwr-15w"
```

```bash
# Instalar el script
mkdir -p ~/scripts
# (copie el contenido de arriba al archivo)
chmod +x ~/scripts/jetson-phase2-clean.sh
echo "alias phase2-clean='~/scripts/jetson-phase2-clean.sh'" >> ~/.bashrc
source ~/.bashrc
```

---

## 18.9 Uso de la CLI Oficial jetson-containers (Opcional)

Además de los comandos `docker` manuales, el proyecto ofrece una CLI que automatiza la construcción local desde código fuente.

```bash
# Instalar la CLI de jetson-containers
sudo apt install -y python3-pip python3-venv
pip3 install --user jetson-containers
```

```bash
# Listar paquetes disponibles
jetson-containers list
```

```bash
# Ejecutar un contenedor con la CLI (manejo automático de tags)
# (Solo si build local es necesario — para la mayoría de usos, docker pull es suficiente)
jetson-containers run dustynv/faster-whisper
```

> **Recomendación:** Para los pipelines de Phase 2, use `docker pull` y `docker run` directamente. La CLI `jetson-containers` es más útil para construir imágenes personalizadas o cuando el tag precompilado no existe.

---

## 18.10 Prerrequisito Memory Check por Pipeline

Antes de cada pipeline de Phase 2, valide la memoria disponible:

```bash
# Función verificación — agregar a ~/.bashrc
check_ready_phase2() {
    local min_gb=${1:-20}
    local pipeline=${2:-"Phase 2"}
    
    local libre=$(awk '/MemAvailable/{printf "%.0f", $2/1024/1024}' /proc/meminfo)
    local temp=$(cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null | awk '{printf "%.0f", $1/1000}')
    local ok=true
    
    echo "── Verificación pre-pipeline: $pipeline ──"
    
    if [ "$libre" -lt "$min_gb" ]; then
        echo "  ⚠️  RAM libre: ${libre} GB (mínimo ${min_gb} GB)"
        echo "      Ejecute: phase2-clean && pwr-15w && sleep 5"
        ok=false
    else
        echo "  ✅ RAM libre: ${libre} GB"
    fi
    
    if [ -n "$temp" ] && [ "$temp" -gt 75 ]; then
        echo "  ⚠️  Temperatura: ${temp}°C (límite: 75°C)"
        echo "      Espere que enfríe antes de cargar modelos"
        ok=false
    elif [ -n "$temp" ]; then
        echo "  ✅ Temperatura: ${temp}°C"
    fi
    
    if [ "$ok" = true ]; then
        echo "  ✅ Sistema listo para $pipeline"
        return 0
    else
        return 1
    fi
}
```

```bash
# Uso al inicio de cada pipeline
source ~/.bashrc
check_ready_phase2 20 "PDF-to-podcast"
```

---

## 18.11 Verificación Final del Capítulo

```bash
# Verificación de configuración de jetson-containers [VERIFICADO EN JP 7.2]
echo "╔══════════════════════════════════════════════════════════╗"
echo "║   VERIFICACIÓN PARTE 18 — JETSON-CONTAINERS             ║"
echo "╚══════════════════════════════════════════════════════════╝"

echo ""
echo "── Docker operativo ──"
docker info --format "  ✅ Docker {{.ServerVersion}} ({{.OSType}}/{{.Architecture}})" 2>/dev/null \
  || echo "  ❌ Docker no accesible"

echo ""
echo "── NVIDIA runtime ──"
docker info 2>/dev/null | grep -qi nvidia \
  && echo "  ✅ Runtime nvidia disponible" \
  || echo "  ⚠️  Runtime nvidia no configurado (ver Parte 8)"

echo ""
echo "── Imágenes disponibles ──"
TOTAL_DUSTYNV=$(docker images | grep -c dustynv 2>/dev/null || echo "0")
TOTAL_NVIDIA=$(docker images | grep -c "nvidia-ai-iot" 2>/dev/null || echo "0")
echo "  Imágenes dustynv: $TOTAL_DUSTYNV"
echo "  Imágenes nvidia-ai-iot: $TOTAL_NVIDIA"

echo ""
echo "── Conectividad a Docker Hub (para pulls futuros) ──"
curl -s --max-time 5 "https://hub.docker.com/v2/repositories/dustynv/" > /dev/null \
  && echo "  ✅ Docker Hub accesible" \
  || echo "  ⚠️  Sin acceso a Docker Hub — verifique conexión de red"

echo ""
echo "── Scripts de Phase 2 ──"
[ -f ~/scripts/jetson-phase2-clean.sh ] \
  && echo "  ✅ jetson-phase2-clean.sh" \
  || echo "  ○  jetson-phase2-clean.sh no instalado (ver §18.8)"

echo ""
echo "── Espacio disponible ──"
df -h / | awk 'NR==2{printf "  Almacenamiento raíz: %s usados, %s disponibles (%s)\n", $3, $4, $5}'
df -h /data 2>/dev/null | awk 'NR==2{printf "  NVMe (/data): %s usados, %s disponibles (%s)\n", $3, $4, $5}' \
  || echo "  (sin NVMe montado en /data)"

echo ""
echo "════════════════════════════════════════════════════════"
```

```
# Salida esperada
── Docker operativo ──
  ✅ Docker 27.x.x (linux/arm64)

── NVIDIA runtime ──
  ✅ Runtime nvidia disponible

── Imágenes disponibles ──
  Imágenes dustynv: 0     ← Se llenan a medida que avanza Phase 2
  Imágenes nvidia-ai-iot: 3

── Conectividad a Docker Hub ──
  ✅ Docker Hub accesible

── Scripts de Phase 2 ──
  ✅ jetson-phase2-clean.sh

── Espacio disponible ──
  Almacenamiento raíz: 45G usados, 890G disponibles (5%)
```

> **Próximo paso:** La Parte 19 usa `dustynv/kokoro-tts` para construir el pipeline completo de conversión de PDF a pódcast: extracción de texto → guión LLM → síntesis de voz → audio final.
