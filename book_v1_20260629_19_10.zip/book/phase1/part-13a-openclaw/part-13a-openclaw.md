# Parte 13A — OpenClaw: Agente Central de IA en el Jetson AGX Orin 64GB

## Introducción

OpenClaw es el agente central que convierte el motor de inferencia del Jetson en un sistema autónomo con capacidad de planificar, actuar y responder. Mientras vLLM o llama.cpp sirven tokens, OpenClaw conecta esos tokens con el mundo real: WhatsApp, herramientas de sistema, búsqueda web, memoria de sesión y ejecución de código.

Esta parte cubre únicamente OpenClaw. Para NemoClaw (capa de seguridad), Open WebUI (interfaz gráfica) y tool calling avanzado, consulte las Partes 13B, 13C y 13D respectivamente.

> **Prerrequisito:** Al menos un motor de inferencia activo (Parte 12) antes de iniciar OpenClaw. Sin modelo respondiendo en el puerto configurado, el gateway arranca pero no puede generar respuestas.

**Modo energético recomendado:** 30W (`pwr-30w`) para el gateway en reposo. Cambie a MAXN (`pwr-maxn`) cuando active el motor de inferencia para tareas intensivas.

---

## 13A.1 Arquitectura de OpenClaw en JetPack 7.2

```
Arquitectura OpenClaw — Jetson AGX Orin 64GB (JP 7.2)
══════════════════════════════════════════════════════

Windows / Teléfono            Jetson AGX Orin 64GB
──────────────────            ────────────────────────────────────────
  WhatsApp App   ──────────→  OpenClaw Gateway  :18789 (loopback)
  Navegador Web  ──────────→      │ (SSH tunnel desde Windows)
  Terminal TUI   ──────────→      │
                                  ▼  (router de solicitudes)
                          ┌─────────────────────────────────┐
                          │  Backend activo (uno a la vez)  │
                          │  vLLM :8000  llama.cpp :8080    │
                          │  Ollama :11434                  │
                          └─────────────────────────────────┘
                                  │
                          Modelo activo (gemma4-E4B, qwen35, etc.)
                          Responde en ~1-3 segundos @ 30W
```

OpenClaw actúa como un router inteligente: recibe la solicitud del canal de entrada, la enruta al backend de inferencia correcto, ejecuta las herramientas que el modelo solicita y entrega la respuesta al canal de salida. **Un solo modelo puede estar activo a la vez** (memoria unificada 64 GB).

---

## 13A.2 Prerrequisitos

### 13A.2.1 Node.js v22

OpenClaw requiere Node.js v22. JetPack 7.2 puede incluirlo, pero verifique antes de instalar:

```bash
# Verificar Node.js [VERIFICADO EN JP 7.2]
node --version
npm --version
```

```
# Salida esperada:
v22.23.1
10.9.x
```

```bash
# Si Node.js no está disponible o es una versión <20:
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs

# Verificar instalación (tarda ~2 minutos)
node --version   # v22.23.1
npm --version    # 10.x.x
```

> **IMPORTANTE:** No use el Node.js del repositorio de Ubuntu 24.04 (`apt install nodejs` sin NodeSource). Ese paquete instala la versión 18.x, incompatible con OpenClaw.

### 13A.2.2 Motor de inferencia activo

OpenClaw necesita un modelo respondiendo en el momento de arranque del gateway. Verifique antes de continuar:

```bash
# Verificar que al menos un motor de inferencia está activo
curl -sf http://localhost:8000/v1/models > /dev/null && echo "✅ vLLM activo en :8000" \
  || curl -sf http://localhost:8080/v1/models > /dev/null && echo "✅ llama.cpp activo en :8080" \
  || curl -sf http://localhost:11434/api/tags > /dev/null && echo "✅ Ollama activo en :11434" \
  || echo "❌ Sin motor activo — inicie uno antes de configurar OpenClaw (ver Parte 12)"
```

---

## 13A.3 Instalación de OpenClaw

El instalador oficial verifica la versión de Node, instala el daemon y prepara el onboarding inicial:

```bash
# Método recomendado: instalador oficial [VERIFICADO EN JP 7.2]
# Tarda 2-3 minutos — descarga el paquete npm y configura el servicio systemd de usuario
curl -fsSL https://openclaw.ai/install.sh | bash
```

```
# Salida esperada al final del instalador:
✅ OpenClaw 2026.6.10 installed
✅ Node.js v22.23.1 detected
✅ Daemon configured as systemd user service
→ Run 'openclaw onboard' to configure your first agent
```

```bash
# Si el comando 'openclaw' no se encuentra después de instalar:
export PATH="$(npm prefix -g)/bin:$PATH"
echo 'export PATH="$(npm prefix -g)/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc

# Verificar instalación
openclaw --version
# Esperado: OpenClaw 2026.6.10
```

**Método alternativo (instalación sin script):**

```bash
# Si el instalador oficial falla por restricciones de red
npm install -g openclaw@latest
openclaw onboard --install-daemon

# Verificar
openclaw --version
```

> **Error común — paquete npm incorrecto:** Si ve alguna guía que usa `@openclaw/cli` o `@openshell/cli`, ese nombre de paquete no existe en el registro npm. El nombre correcto es simplemente `openclaw` (sin prefijo `@`).

---

## 13A.4 Configuración de Producción

La configuración reside en `~/.openclaw/openclaw.json`. La siguiente es la configuración completa verificada en producción con todos los parches aplicados.

### 13A.4.1 Generar el Token del Gateway

```bash
# Generar token de seguridad para el gateway [VERIFICADO EN JP 7.2]
GATEWAY_TOKEN=$(openssl rand -hex 24)
echo "Token generado: $GATEWAY_TOKEN"
# Salida ejemplo: Token generado: a3f7c2e9d4b1a8f6c3d2e5a7b4c9d1e2f3a6b8c4d7e9f2
```

### 13A.4.2 Configuración JSON Completa

```bash
# Hacer backup si existe configuración previa
cp ~/.openclaw/openclaw.json \
   ~/.openclaw/openclaw.json.bak.$(date +%Y%m%d_%H%M%S) 2>/dev/null || true

# Escribir configuración de producción [VERIFICADO EN JP 7.2]
cat > ~/.openclaw/openclaw.json << EOF
{
  "agents": {
    "defaults": {
      "workspace": "/home/jetson/.openclaw/workspace",
      "models": {
        "vllm/google/gemma-4-E4B-it": {}
      },
      "model": {
        "primary": "vllm/google/gemma-4-E4B-it"
      },
      "compaction": {
        "reserveTokensFloor": 6000
      },
      "timeoutSeconds": 300,
      "memorySearch": {
        "enabled": false
      },
      "bootstrapMaxChars": 20000,
      "bootstrapTotalMaxChars": 150000,
      "contextInjection": "always"
    }
  },
  "gateway": {
    "mode": "local",
    "auth": {
      "mode": "token",
      "token": "${GATEWAY_TOKEN}"
    },
    "port": 18789,
    "bind": "loopback",
    "tailscale": { "mode": "off", "resetOnExit": false },
    "controlUi": { "allowInsecureAuth": true },
    "nodes": {
      "denyCommands": [
        "camera.snap", "camera.clip", "screen.record",
        "contacts.add", "calendar.add", "reminders.add",
        "sms.send", "sms.search"
      ]
    }
  },
  "session": {
    "dmScope": "per-channel-peer"
  },
  "tools": {
    "profile": "full",
    "web": {
      "search": { "provider": "brave", "enabled": true }
    }
  },
  "plugins": {
    "entries": {
      "vllm": { "enabled": true },
      "whatsapp": { "enabled": true },
      "brave": {
        "config": { "webSearch": { "apiKey": "TU_BRAVE_API_KEY" } },
        "enabled": true
      }
    }
  },
  "models": {
    "mode": "merge",
    "providers": {
      "vllm": {
        "baseUrl": "http://127.0.0.1:8000/v1",
        "api": "openai-completions",
        "apiKey": "vllm-local",
        "timeoutSeconds": 300,
        "models": [
          {
            "id": "google/gemma-4-E4B-it",
            "name": "Gemma 4 E4B (local vLLM)",
            "reasoning": false,
            "input": ["text", "image"],
            "cost": { "input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0 },
            "contextWindow": 65536,
            "maxTokens": 4096
          }
        ]
      }
    }
  },
  "auth": {
    "profiles": {
      "vllm:default": { "provider": "vllm", "mode": "api_key" }
    }
  },
  "channels": {
    "whatsapp": {
      "enabled": true,
      "selfChatMode": false,
      "dmPolicy": "pairing"
    }
  },
  "commands": {
    "ownerAllowFrom": ["whatsapp:+57XXXXXXXXXX"]
  },
  "hooks": {
    "internal": {
      "enabled": true,
      "entries": {
        "session-memory": { "enabled": true },
        "boot-md": { "enabled": true },
        "bootstrap-extra-files": { "enabled": true },
        "command-logger": { "enabled": true },
        "compaction-notifier": { "enabled": true }
      }
    }
  }
}
EOF

# Validar JSON
python3 -m json.tool ~/.openclaw/openclaw.json > /dev/null \
  && echo "✅ Config JSON válida" \
  || echo "❌ Error en JSON — revisar con: python3 -m json.tool ~/.openclaw/openclaw.json"
```

```bash
# Aplicar configuración y arrancar el gateway
openclaw gateway restart
sleep 5
openclaw doctor
```

```
# Salida esperada de 'openclaw doctor':
✅ Gateway: running on port 18789
✅ Model: vllm/google/gemma-4-E4B-it (connected)
✅ Tools profile: full
✅ WhatsApp: enabled (pending pairing)
```

### 13A.4.3 Tabla de Errores Críticos de Configuración (todos verificados en producción)

| Campo incorrecto | Valor que falla | Valor correcto | Consecuencia |
|-----------------|-----------------|----------------|--------------|
| `tools.profile` | `"default"` | `"full"` | WhatsApp no puede responder mensajes |
| `tools.profile` | `"coding"` | `"full"` | Perfil coding elimina la herramienta de respuesta WhatsApp |
| `models.providers.vllm.apiKey` | `"VLLM_API_KEY"` | `"vllm-local"` | Error de autenticación contra el endpoint local |
| `models.providers.vllm.models[].id` | `"vllm/google/gemma-4-E4B-it"` | `"google/gemma-4-E4B-it"` | El prefijo `vllm/` no va en el campo `id` del modelo |
| `agents.defaults.model.primary` | `"vllm/google/gemma4-E4B-it"` | `"vllm/google/gemma-4-E4B-it"` | El guión en `gemma-4` es obligatorio |
| `models.providers.vllm.models[].maxTokens` | `65536` | `4096` | Si maxTokens == contextWindow, no queda espacio para el input |
| `agents.defaults.memorySearch.enabled` | `true` | `false` | Falla silenciosamente sin API key de OpenAI |

---

## 13A.5 Acceso Web UI desde Windows (Túnel SSH)

El gateway escucha únicamente en `loopback` (127.0.0.1:18789), inaccesible desde la red local por diseño. Para acceder desde Windows se requiere un túnel SSH.

> **ADVERTENCIA:** El túnel SSH se ejecuta **desde Windows** hacia el Jetson, NO al revés. Si lo ejecuta desde el propio Jetson, recibirá `Permission denied (publickey)`.

```powershell
# En Windows PowerShell — mantener esta ventana abierta mientras usa el Web UI
# Reemplazar 192.168.1.100 con la IP de su Jetson
ssh -N -L 18789:127.0.0.1:18789 jetson@192.168.1.100
```

Abra en el navegador de Windows:

```
http://localhost:18789/#token=TU_TOKEN_AQUI
```

```bash
# Obtener el token desde el Jetson
openclaw config get gateway.auth.token
# Salida: abc123def456...  (48 caracteres hexadecimales)
```

**Alternativa — NoMachine (más sencilla, sin túnel):**

Si tiene NoMachine instalado (Parte 7), conéctese con el cliente NoMachine desde Windows y abra el navegador dentro del escritorio virtual del Jetson:

```
http://127.0.0.1:18789/#token=TU_TOKEN
```

---

## 13A.6 Canal WhatsApp — Configuración Inicial

WhatsApp es el canal principal de interacción del agente. La configuración inicial requiere escanear un código QR.

```bash
# Paso 1: Asistente de onboarding [VERIFICADO EN JP 7.2]
# Aparece un código QR en la terminal o en http://localhost:18789
openclaw onboard

# Durante el asistente, seleccionar:
# ✓ Channel: WhatsApp
# ✓ dmPolicy: pairing (nuevos contactos reciben código de 6 caracteres)
# ✓ Search provider: Brave Search (requiere API key en brave.com/search/api/)
# ✓ Hooks: habilitar los 5 disponibles
# ✓ Gateway service: Install (systemd usuario)
```

```bash
# Paso 2: En el teléfono — WhatsApp → Configuración → Dispositivos vinculados → Vincular dispositivo
# Apuntar la cámara al QR en la terminal del Jetson

# Paso 3: Aprobar el número de teléfono del remitente
openclaw pairing list whatsapp
# Salida: pending  +573XXXXXXXXX  code: A7K2M9

openclaw pairing approve whatsapp A7K2M9
# Salida: Approved whatsapp sender +573XXXXXXXXX
#         Command owner configured whatsapp:+573XXXXXXXXX

# Paso 4: Verificar conexión WhatsApp
openclaw channels status --probe
```

```
# Salida esperada:
WhatsApp default: enabled, configured, linked, running, connected ✅
```

**Si WhatsApp se desconecta** (`session logged out` o `QR required`):

```bash
openclaw channels auth login whatsapp
```

**Políticas de acceso:**

```bash
# Política pairing (defecto): nuevos contactos reciben código de 6 caracteres
openclaw config set channels.whatsapp.dmPolicy pairing

# Política allowlist: solo números pre-autorizados
openclaw config set channels.whatsapp.dmPolicy allowlist
openclaw config set channels.whatsapp.dmAllowFrom '["+573XXXXXXXXX","+571XXXXXXXX"]'
```

---

## 13A.7 Cambiar el Modelo de Inferencia

Para cambiar el modelo que usa OpenClaw, actualice la configuración y reinicie el gateway:

```bash
# Cambiar a Qwen3.5 35B (si vLLM está sirviendo qwen35 en :8000) [VERIFICADO EN JP 7.2]
openclaw config set \
  agents.defaults.model.primary "vllm/qwen35" \
  models.providers.vllm.models.0.id "qwen35" \
  models.providers.vllm.models.0.contextWindow 8192

openclaw gateway restart
sleep 3
openclaw doctor | grep "Model:"
# Salida esperada: ✅ Model: vllm/qwen35 (connected)
```

```bash
# Cambiar a llama.cpp (Nemotron Omni en :8080)
openclaw config set \
  agents.defaults.model.primary "llama/nemotron-omni" \
  models.providers.llama.baseUrl "http://127.0.0.1:8080/v1" \
  models.providers.llama.models.0.id "nemotron-omni"

openclaw gateway restart
```

---

## 13A.8 Gestión del Gateway en el Día a Día

```bash
# Estado completo del gateway [VERIFICADO EN JP 7.2]
openclaw gateway status

# Reiniciar (necesario después de cambiar openclaw.json)
openclaw gateway restart && sleep 3 && openclaw gateway status

# Ver logs en tiempo real
openclaw logs --follow

# Filtrar solo logs de WhatsApp
openclaw logs --follow | grep -i whatsapp

# Filtrar solo errores
openclaw logs --follow | grep -i error

# Interfaz TUI interactiva en la terminal
openclaw tui
# Dentro del TUI: /new → nueva sesión | /compact → compactar contexto | /quit → salir

# Verificar que el modelo responde antes de depurar OpenClaw
curl -s http://localhost:8000/v1/models \
  | python3 -c "import sys,json; [print(m['id']) for m in json.load(sys.stdin)['data']]"
```

---

## 13A.9 Skills de OpenClaw

Los skills amplían las capacidades del agente con herramientas adicionales.

```bash
# Ver skills instalados [VERIFICADO EN JP 7.2]
openclaw skills list --verbose

# Verificar estado de todos los skills
openclaw skills check

# Instalar un skill del registro ClawHub
openclaw skills install <nombre-del-skill>

# Skills recomendados para el Jetson:
# jetson-system   → información del hardware, temperatura, modo de energía
# file-manager    → gestión de archivos via chat o WhatsApp
# code-executor   → ejecutar scripts Python desde WhatsApp (usar con precaución)
```

---

## 13A.10 Aliases para el Día a Día

```bash
# Agregar al ~/.bashrc [VERIFICADO EN JP 7.2]
cat >> ~/.bashrc << 'EOF'

# ── OpenClaw ───────────────────────────────────────────────────────────
alias openclaw-start='openclaw gateway start && sleep 3 && openclaw gateway status'
alias openclaw-stop='openclaw gateway stop'
alias openclaw-restart='openclaw gateway restart && sleep 3 && openclaw doctor'
alias openclaw-status='openclaw gateway status && openclaw channels status'
alias openclaw-logs='openclaw logs --follow'
alias openclaw-doctor='openclaw doctor'
alias openclaw-wa='openclaw channels status --probe | grep -i whatsapp'
EOF

source ~/.bashrc
```

---

## 13A.11 Solución de Problemas

### Error: `model not found` al arrancar el gateway

**Causa:** El backend de inferencia no está activo o el ID del modelo no coincide.

```bash
# Verificar que vLLM está activo y con el modelo correcto
curl -s http://localhost:8000/v1/models | python3 -m json.tool

# Si vLLM no está corriendo, iniciarlo (ver Part 12 o alias start-qwen35/start-nemotron)
start-qwen35   # o el alias correspondiente al modelo configurado

# Reiniciar OpenClaw después de que el modelo esté listo
openclaw gateway restart
```

### Error: `Permission denied` al abrir el Web UI

**Causa:** El túnel SSH se ejecutó desde el Jetson en lugar de desde Windows.

```bash
# INCORRECTO (desde el Jetson):
ssh -N -L 18789:127.0.0.1:18789 localhost   # ← No hacer esto

# CORRECTO (desde Windows PowerShell):
ssh -N -L 18789:127.0.0.1:18789 jetson@192.168.1.100
```

### WhatsApp: mensajes sin respuesta del agente

**Causa más común:** El perfil de herramientas no es `"full"`.

```bash
# Verificar el perfil actual
grep '"profile"' ~/.openclaw/openclaw.json

# Si muestra "default", "coding" o cualquier otro valor:
openclaw config set tools.profile full
openclaw gateway restart
```

### Gateway arranca pero no conecta al modelo

```bash
# Verificar URL del backend en la config
python3 -c "
import json
with open('/home/jetson/.openclaw/openclaw.json') as f:
    c = json.load(f)
url = c['models']['providers']['vllm']['baseUrl']
print('Backend URL:', url)
"

# Probar conectividad al backend directamente
curl -sf "$URL/models" && echo "✅ Backend accesible" || echo "❌ Backend no responde"
```

---

## Resumen de la Parte 13A

OpenClaw es el agente central que conecta los modelos del Jetson con WhatsApp, navegador y terminal. Los puntos críticos de la configuración son:

- `tools.profile` debe ser `"full"` — cualquier otro valor rompe las respuestas de WhatsApp
- El campo `models.providers.vllm.models[].id` no lleva el prefijo `vllm/` — va en el campo `agents.defaults.model.primary`
- `memorySearch.enabled` debe ser `false` a menos que tenga una API key de OpenAI configurada
- El gateway escucha en loopback `:18789` — acceda desde Windows solo via túnel SSH o NoMachine

La siguiente parte (13B) cubre NemoClaw, la capa de seguridad L7 que envuelve a OpenClaw con políticas de red y aislamiento de sistema de archivos.
