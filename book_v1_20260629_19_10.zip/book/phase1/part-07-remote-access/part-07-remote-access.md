# Parte 7 — Acceso Remoto y Modo Headless: SSH, IP Estática y NoMachine

## Introducción

El Jetson AGX Orin está diseñado para operar sin monitor, teclado ni ratón físicos. Esta configuración — denominada *headless* o sin cabeza — es la forma más eficiente de trabajar con el dispositivo, ya que evita el consumo de recursos que genera el entorno gráfico local y permite acceder al sistema desde cualquier computadora de la red.

Este capítulo configura tres capas de acceso remoto complementarias:

1. **SSH** — acceso a la línea de comandos desde cualquier terminal (Linux, macOS, Windows)
2. **IP estática** — garantiza que la dirección del Jetson no cambie tras cada reinicio
3. **NoMachine** — acceso al entorno gráfico remoto cuando se necesite una interfaz visual

> **NOTA sobre el orden:** Este capítulo asume que la Parte 1 (primer arranque) está completa y que ya tiene acceso básico a una terminal en el Jetson, ya sea por monitor local o por la sesión SSH inicial configurada en la Parte 1.

**Prerequisito:** Parte 1 completada — Jetson con Ubuntu 24.04 y conexión de red básica.

**Tiempo estimado:** 30–45 minutos.

**Al final de esta parte tendrá:**
- SSH con clave pública configurado (sin contraseña)
- IP estática asignada al Jetson en su red local
- NoMachine instalado y accesible desde Windows/macOS/Linux
- Sistema configurado para arrancar en modo headless (sin entorno gráfico local)

---

## 7.1 SSH — Acceso por Línea de Comandos

SSH (Secure Shell) es el método principal para administrar el Jetson. Permite ejecutar comandos, transferir archivos y crear túneles cifrados desde cualquier computadora de la red.

### 7.1.1 Verificar que SSH está activo [VERIFICADO EN JP 7.2]

```bash
# Verificar estado del servicio SSH
sudo systemctl status ssh
```

```
# Salida esperada
● ssh.service - OpenBSD Secure Shell server
     Loaded: loaded (/usr/lib/systemd/system/ssh.service; enabled; preset: enabled)
     Active: active (running) since ...
   Main PID: 1234 (sshd)
```

Si el servicio no está activo o no está instalado:

```bash
# Instalar y habilitar SSH [VERIFICADO EN JP 7.2]
sudo apt update && sudo apt install -y openssh-server
sudo systemctl enable --now ssh
```

```
# Salida esperada (enable)
Synchronizing state of ssh.service with SysV service script with /usr/lib/systemd/systemd-sysv-install.
Executing: /usr/lib/systemd/systemd-sysv-install enable ssh
Created symlink /etc/systemd/system/sshd.service → /lib/systemd/system/ssh.service
```

### 7.1.2 Conectar desde Windows, macOS o Linux [VERIFICADO EN JP 7.2]

Primero, determine la dirección IP actual del Jetson:

```bash
# En el Jetson — ver IPs de todas las interfaces
ip addr show | grep "inet " | grep -v 127
```

```
# Salida esperada
    inet 192.168.1.100/24 brd 192.168.1.255 scope global dynamic noprefixroute eth0
```

Desde su computadora:

```bash
# Desde Linux o macOS (terminal nativa)
ssh jetson@192.168.1.100

# Desde Windows (PowerShell, Terminal, o Git Bash)
ssh jetson@192.168.1.100
```

```
# Primera conexión — salida esperada
The authenticity of host '192.168.1.100 (192.168.1.100)' can't be established.
ED25519 key fingerprint is SHA256:...
Are you sure you want to continue connecting (yes/no/[fingerprint])? yes

Warning: Permanently added '192.168.1.100' (ED25519) to the list of known hosts.
jetson@192.168.1.100's password:
```

Escriba su contraseña (la que configuró en el OEM setup de la Parte 1). En conexiones futuras ya no pedirá confirmación del fingerprint.

### 7.1.3 Configurar Acceso sin Contraseña (Clave SSH) [VERIFICADO EN JP 7.2]

La autenticación con contraseña es conveniente pero menos segura y más lenta que el uso de claves. Genere un par de claves en su computadora:

**En su computadora (no en el Jetson):**

```bash
# Generar clave ED25519 (más moderna y segura que RSA)
ssh-keygen -t ed25519 -C "jetson-access" -f ~/.ssh/id_jetson

# Copiar la clave pública al Jetson
ssh-copy-id -i ~/.ssh/id_jetson.pub jetson@192.168.1.100
```

```
# Salida esperada de ssh-copy-id
/usr/bin/ssh-copy-id: INFO: Source of key(s) to be installed: "/home/usuario/.ssh/id_jetson.pub"
Number of key(s) added: 1

Now try logging into the machine, with:   "ssh -i ~/.ssh/id_jetson jetson@192.168.1.100"
and check to make sure that only the key(s) you wanted were added.
```

**En Windows (PowerShell):**

```powershell
# Generar clave
ssh-keygen -t ed25519 -C "jetson-access" -f "$env:USERPROFILE\.ssh\id_jetson"

# Copiar la clave al Jetson (requiere que SSH esté activo en el Jetson)
type "$env:USERPROFILE\.ssh\id_jetson.pub" | ssh jetson@192.168.1.100 "mkdir -p ~/.ssh && cat >> ~/.ssh/authorized_keys"
```

Configurar el archivo `~/.ssh/config` en su computadora para simplificar las conexiones:

```
# En ~/.ssh/config de su computadora (crear si no existe)
Host jetson
    HostName 192.168.1.100
    User jetson
    IdentityFile ~/.ssh/id_jetson
    ServerAliveInterval 60
    ServerAliveCountMax 3
```

A partir de aquí puede conectarse simplemente con:

```bash
# Conexión simplificada con alias
ssh jetson
```

```
# Salida esperada (sin pedir contraseña)
Welcome to Ubuntu 24.04.4 LTS (GNU/Linux 6.8.12-tegra aarch64)
jetson@ubuntu:~$
```

### 7.1.4 Transferir Archivos por SSH [VERIFICADO EN JP 7.2]

```bash
# Copiar un archivo desde su PC al Jetson
scp archivo.txt jetson:~/

# Copiar un directorio completo
scp -r ~/proyecto/ jetson:~/proyectos/

# Descargar un archivo del Jetson a su PC
scp jetson:~/resultados/benchmark.log ~/desktop/

# Sincronizar directorio completo (más eficiente que scp para grandes cambios)
rsync -avz --progress ~/datos/ jetson:~/datos/
```

---

## 7.2 Configurar IP Estática

Sin una IP estática, el Jetson puede recibir una dirección diferente cada vez que se reinicia (según la política DHCP de su router), lo que hace imposible mantener una configuración fija de SSH o NoMachine.

### 7.2.1 Identificar la Interfaz de Red y la Configuración Actual

```bash
# Ver nombre de la interfaz de red (generalmente eth0, enp3s0, o l4tbr0)
ip link show | grep -E "^[0-9]+: " | grep -v lo
```

```
# Salida esperada (ejemplo)
2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP ...
```

```bash
# Ver IP actual, gateway y servidores DNS
ip addr show eth0 | grep "inet "
ip route | grep default
resolvectl status eth0 | grep "DNS Servers"
```

```
# Salida esperada
    inet 192.168.1.100/24 brd 192.168.1.255 scope global dynamic noprefixroute eth0
default via 192.168.1.1 dev eth0 proto dhcp
    DNS Servers: 8.8.8.8
```

Anote estos valores — los usará para configurar la IP estática:
- **IP actual:** `192.168.1.100` (elegir una fuera del rango DHCP del router)
- **Gateway:** `192.168.1.1`
- **Prefijo:** `/24`

### 7.2.2 Configurar IP Estática con Netplan [VERIFICADO EN JP 7.2]

Ubuntu 24.04 usa Netplan para la configuración de red. Los archivos de configuración están en `/etc/netplan/`.

```bash
# Ver archivos de configuración existentes
ls /etc/netplan/
```

```
# Salida esperada (el nombre puede variar)
50-cloud-init.yaml
```

```bash
# Crear la configuración de red estática
# Adapte los valores de addresses, gateway4 y nameservers a su red
sudo tee /etc/netplan/01-static-ip.yaml > /dev/null << 'EOF'
network:
  version: 2
  renderer: NetworkManager
  ethernets:
    eth0:
      dhcp4: no
      addresses:
        - 192.168.1.100/24
      routes:
        - to: default
          via: 192.168.1.1
      nameservers:
        addresses:
          - 8.8.8.8
          - 1.1.1.1
EOF

# Dar permisos correctos (Netplan exige 600 para archivos con contraseñas/claves)
sudo chmod 600 /etc/netplan/01-static-ip.yaml
```

> **IMPORTANTE:** Reemplace `eth0` con el nombre real de su interfaz (obtenido en el paso anterior). Reemplace `192.168.1.100` con la IP que desea asignar al Jetson y `192.168.1.1` con el gateway de su router.

```bash
# Probar la configuración sin aplicarla permanentemente (revertirá en 120 seg si no confirma)
sudo netplan try
```

```
# Salida esperada
Do you want to keep these settings?

Press ENTER before the timeout to accept the new configuration

Changes will revert in 120 seconds
Configuration accepted.
```

```bash
# Aplicar la configuración permanentemente
sudo netplan apply

# Verificar la nueva IP
ip addr show eth0 | grep "inet "
```

```
# Salida esperada
    inet 192.168.1.100/24 brd 192.168.1.255 scope global noprefixroute eth0
```

La diferencia entre la salida anterior y la nueva: ya no aparece `dynamic` — significa que la IP es estática.

```bash
# Verificar conectividad
ping -c 3 8.8.8.8
```

```
# Salida esperada
PING 8.8.8.8 (8.8.8.8) 56(84) bytes of data.
64 bytes from 8.8.8.8: icmp_seq=1 ttl=117 time=12.3 ms
64 bytes from 8.8.8.8: icmp_seq=2 ttl=117 time=11.8 ms
64 bytes from 8.8.8.8: icmp_seq=3 ttl=117 time=12.1 ms
```

### 7.2.3 Errores Comunes de Netplan

| Error | Causa | Solución |
|-------|-------|----------|
| `Netplan policy not found` | Archivo con permisos incorrectos | `sudo chmod 600 /etc/netplan/01-static-ip.yaml` |
| `Invalid YAML` | Error de indentación (usar espacios, no tabs) | Verificar con `python3 -c "import yaml; yaml.safe_load(open('/etc/netplan/01-static-ip.yaml'))"` |
| Sin internet tras aplicar | Gateway incorrecto | Verificar IP del router con `ip route | grep default` antes de cambiar |
| `eth0: no such device` | Nombre de interfaz incorrecto | Corregir con el nombre real de `ip link show` |

---

## 7.3 Modo Headless — Arranque sin Entorno Gráfico Local

El Jetson arranca por defecto en modo gráfico (`graphical.target`), lo que activa GNOME, GDM y una cascada de servicios que consumen 1.5–3 GB de RAM sin ningún beneficio en producción. Cambiar a `multi-user.target` elimina toda la interfaz gráfica local y libera esos recursos.

> **NOTA:** NoMachine crea su propia sesión gráfica virtual — no necesita que el entorno gráfico local esté activo para funcionar. SSH nunca requirió entorno gráfico.

```bash
# Cambiar a modo headless permanentemente [VERIFICADO EN JP 7.2]
sudo systemctl set-default multi-user.target
```

```
# Salida esperada
Created symlink /etc/systemd/system/default.target → /lib/systemd/system/multi-user.target
```

```bash
# Verificar el cambio (sin reiniciar)
systemctl get-default
```

```
# Salida esperada
multi-user.target
```

El cambio se aplica en el próximo reinicio. Si necesita el escritorio local en este momento, use `sudo systemctl start graphical.target`. Después del próximo reboot ya solo iniciará en modo texto.

```bash
# Verificar tras el reinicio
sudo reboot
# ... (reconectar por SSH después)
systemctl get-default
systemctl is-active gdm3
```

```
# Salida esperada
multi-user.target
inactive
```

---

## 7.4 NoMachine — Escritorio Gráfico Remoto

NoMachine es la solución más eficiente para acceder al entorno gráfico del Jetson de forma remota. A diferencia de VNC o RDP, el protocolo NX de NoMachine comprime eficientemente el escritorio y tiene latencia muy baja incluso en redes Wi-Fi.

### 7.4.1 Instalar NoMachine en el Jetson [VERIFICADO EN JP 7.2]

```bash
# Descargar la versión ARM64 de NoMachine para Ubuntu/Debian
# (obtener el enlace actualizado desde nomachine.com/download/linux)
cd ~
wget "https://download.nomachine.com/download/8.14/Arm/nomachine_8.14.2_1_arm64.deb" \
  -O nomachine_arm64.deb
```

```bash
# Instalar
sudo dpkg -i nomachine_arm64.deb
```

```
# Salida esperada
(Reading database ... 320150 files and directories currently installed.)
Preparing to unpack nomachine_arm64.deb ...
NoMachine is going to install nxserver on this computer...
[ INSTALL ] Installing NoMachine ...
[ INFO ] Using installation path: /usr/NX
[ INSTALL ] Copying files ...
[ INSTALL ] Creating the NoMachine group ...
NoMachine was successfully installed.
```

```bash
# Verificar el servicio
sudo systemctl status nxserver 2>/dev/null || sudo /usr/NX/bin/nxserver --status
```

```
# Salida esperada
NoMachine server is running.
```

### 7.4.2 Configurar Display Virtual para Modo Headless [VERIFICADO EN JP 7.2]

En modo headless (sin monitor físico conectado), el servidor gráfico no tiene una pantalla real a la que conectarse. NoMachine necesita una pantalla virtual para poder mostrar el escritorio.

**Paso 1 — Instalar el driver de display virtual:**

```bash
sudo apt install -y xserver-xorg-video-dummy
```

**Paso 2 — Crear la configuración Xorg para pantalla virtual:**

```bash
# Crear directorio si no existe
sudo mkdir -p /etc/X11/xorg.conf.d/

# Crear configuración de pantalla virtual Tegra (usa el GPU del Jetson)
sudo tee /etc/X11/xorg.conf.d/30-headless-display.conf > /dev/null << 'EOF'
Section "Device"
    Identifier  "Tegra0"
    Driver      "dummy"
    Option      "IgnoreEDID" "true"
    Option      "UseEDID" "false"
    VideoRam    256000
EndSection

Section "Monitor"
    Identifier  "Monitor0"
    HorizSync   28-80
    VertRefresh 48-75
    Modeline    "1920x1080_60" 148.50 1920 2008 2052 2200 1080 1084 1089 1125 +Hsync +Vsync
EndSection

Section "Screen"
    Identifier  "Screen0"
    Device      "Tegra0"
    Monitor     "Monitor0"
    DefaultDepth 24
    SubSection "Display"
        Depth   24
        Modes   "1920x1080_60"
        Virtual 1920 1080
    EndSubSection
EndSection
EOF
```

**Paso 3 — Deshabilitar Wayland y usar X11:**

NoMachine no es compatible con Wayland (el nuevo protocolo gráfico). Ubuntu 24.04 usa Wayland por defecto; debe forzar X11:

```bash
# Editar la configuración de GDM
sudo sed -i 's/#WaylandEnable=false/WaylandEnable=false/' /etc/gdm3/custom.conf

# Verificar que se aplicó
grep "WaylandEnable" /etc/gdm3/custom.conf
```

```
# Salida esperada
WaylandEnable=false
```

**Paso 4 — Instalar entorno gráfico ligero (si usa GNOME puede tener pantalla negra):**

GNOME en modo headless puede mostrar pantalla negra en NoMachine porque su compositor (Mutter) requiere aceleración de hardware que el display virtual no provee completamente. XFCE4 es la solución:

```bash
# Instalar XFCE4 (entorno gráfico ligero, ~500MB)
# Solo si tiene pantalla negra con GNOME en NoMachine
sudo apt install -y xfce4 xfce4-goodies
```

```bash
# Configurar NoMachine para usar XFCE en modo headless
sudo tee /etc/NX/nxserver.conf.d/10-headless.conf > /dev/null << 'EOF'
DefaultDesktopCommand "/usr/bin/startxfce4"
CommandStartGnomeSession 0
EOF
```

**Paso 5 — Reiniciar NoMachine para aplicar los cambios:**

```bash
# Reiniciar el servidor NoMachine [VERIFICADO EN JP 7.2]
sudo /usr/NX/bin/nxserver --restart
```

```
# Salida esperada
Restarting NoMachine server...
NoMachine server is running.
```

### 7.4.3 Conectar desde su PC a NoMachine

1. Descargue e instale el **cliente NoMachine** en su computadora desde `nomachine.com`
2. Abra NoMachine y haga clic en **New Connection**
3. Configure:
   - **Protocol:** NX
   - **Host:** `192.168.1.100` (la IP estática del Jetson)
   - **Port:** 4000 (puerto por defecto de NoMachine)
4. En **Authentication:** seleccione "Password" y use las credenciales del Jetson
5. Haga clic en **Connect**

Al conectar verá el escritorio gráfico del Jetson en una ventana de su PC. La latencia es typical ≤30ms en la misma red local.

### 7.4.4 Hacer NoMachine Persistente (Arranque Automático) [VERIFICADO EN JP 7.2]

A diferencia de los motores de inferencia, NoMachine SÍ debe iniciar automáticamente con el sistema, ya que es el canal de acceso remoto de respaldo:

```bash
# Verificar si NoMachine tiene servicio systemd
sudo systemctl status nxserver 2>/dev/null
```

Si el servicio systemd no existe o no está habilitado:

```bash
# Crear servicio systemd para NoMachine [VERIFICADO EN JP 7.2]
sudo tee /etc/systemd/system/nomachine.service > /dev/null << 'EOF'
[Unit]
Description=NoMachine Remote Desktop Server
After=network.target multi-user.target
Wants=network.target

[Service]
Type=oneshot
ExecStart=/usr/NX/bin/nxserver --startup
ExecStop=/usr/NX/bin/nxserver --shutdown
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable nomachine
sudo systemctl start nomachine
sudo systemctl status nomachine
```

```
# Salida esperada
● nomachine.service - NoMachine Remote Desktop Server
     Loaded: loaded (/etc/systemd/system/nomachine.service; enabled; ...)
     Active: active (exited) since ...
```

### 7.4.5 Errores Comunes de NoMachine

| Error | Causa | Solución |
|-------|-------|----------|
| Pantalla negra al conectar | GNOME + Wayland activo | Instalar XFCE4 + desactivar Wayland (`WaylandEnable=false`) |
| `Connection refused` en puerto 4000 | Servicio NoMachine no activo | `sudo /usr/NX/bin/nxserver --startup` |
| Resolución incorrecta (muy baja) | Configuración Xorg sin modeline personalizado | Verificar `/etc/X11/xorg.conf.d/30-headless-display.conf` |
| Pantalla negra solo en headless | Sin display virtual | Verificar que `xserver-xorg-video-dummy` está instalado |
| "Authentication failed" | Contraseña incorrecta o usuario PAM | Verificar con `sudo /usr/NX/bin/nxserver --usercheck jetson` |

---

## 7.5 Verificación Final del Capítulo

```bash
# Script de verificación de acceso remoto [VERIFICADO EN JP 7.2]
echo "╔══════════════════════════════════════════════════════╗"
echo "║         VERIFICACIÓN PARTE 7 — ACCESO REMOTO        ║"
echo "╚══════════════════════════════════════════════════════╝"

echo ""
echo "── SSH ──"
systemctl is-active ssh && echo "  ✅ SSH activo" || echo "  ❌ SSH inactivo"
ss -tlnp | grep :22 > /dev/null && echo "  ✅ Puerto 22 escuchando" || echo "  ❌ Puerto 22 no disponible"

echo ""
echo "── Red ──"
IP=$(ip addr show eth0 2>/dev/null | grep "inet " | awk '{print $2}' | cut -d/ -f1)
if [[ "$IP" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    echo "  ✅ IP del Jetson: $IP"
else
    echo "  ⚠️  No se pudo detectar IP — verificar interfaz de red"
fi
ping -c 1 -W 2 8.8.8.8 > /dev/null 2>&1 && echo "  ✅ Conectividad externa (8.8.8.8)" || echo "  ⚠️  Sin conectividad externa"

echo ""
echo "── Modo de Arranque ──"
DEFAULT=$(systemctl get-default)
if [[ "$DEFAULT" == "multi-user.target" ]]; then
    echo "  ✅ Modo headless configurado ($DEFAULT)"
else
    echo "  ℹ️  Modo actual: $DEFAULT (ejecute: sudo systemctl set-default multi-user.target)"
fi

echo ""
echo "── NoMachine ──"
if /usr/NX/bin/nxserver --status 2>/dev/null | grep -q "running"; then
    echo "  ✅ NoMachine activo"
elif sudo systemctl is-active nomachine 2>/dev/null | grep -q "active"; then
    echo "  ✅ NoMachine (systemd) activo"
else
    echo "  ⚠️  NoMachine no detectado — ver Sección 7.4"
fi

echo ""
echo "── Clave SSH ──"
if [ -f ~/.ssh/authorized_keys ] && [ -s ~/.ssh/authorized_keys ]; then
    echo "  ✅ Claves SSH autorizadas: $(wc -l < ~/.ssh/authorized_keys) clave(s)"
else
    echo "  ℹ️  Sin claves SSH — la autenticación usará contraseña (ver Sección 7.1.3)"
fi

echo ""
echo "═════════════════════════════════════════════════════"
```

```
# Salida esperada
── SSH ──
  ✅ SSH activo
  ✅ Puerto 22 escuchando

── Red ──
  ✅ IP del Jetson: 192.168.1.100
  ✅ Conectividad externa (8.8.8.8)

── Modo de Arranque ──
  ✅ Modo headless configurado (multi-user.target)

── NoMachine ──
  ✅ NoMachine activo

── Clave SSH ──
  ✅ Claves SSH autorizadas: 1 clave(s)
```

> **Próximo paso:** La Parte 8 instala Docker y el NVIDIA Container Toolkit — la base para ejecutar modelos LLM en contenedores GPU-acelerados, incluyendo todos los modelos de la Parte 14.
