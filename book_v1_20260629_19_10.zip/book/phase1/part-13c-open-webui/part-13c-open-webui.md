# Parte 13C — Open WebUI: Interfaz Gráfica para Todos los Motores del Jetson

## Introducción

Open WebUI proporciona una interfaz web estilo ChatGPT que conecta simultáneamente con Ollama, vLLM y llama.cpp desde cualquier navegador de la red local. Es la opción más accesible para usuarios que prefieren una interfaz gráfica en lugar de la terminal o WhatsApp, y funciona como PWA (Progressive Web App) en dispositivos móviles.

A diferencia de los motores de inferencia, Open WebUI **no carga modelos en GPU** — consume únicamente ~200–400 MB de RAM como servidor web. Por esto su contenedor puede usar `--restart unless-stopped` (política más flexible) sin violar la arquitectura clean-start.

**Modo energético:** 30W — Open WebUI es una aplicación web liviana que no necesita MAXN.

> **Prerrequisito:** Docker activo (`docker-on`) y al menos un motor de inferencia corriendo (Ollama, vLLM o llama.cpp).

---

## 13C.1 Instalación

### 13C.1.1 Primer Arranque

```bash
# Activar Docker si está desactivado [VERIFICADO EN JP 7.2]
docker-on   # alias: sudo systemctl start docker.socket && sudo systemctl start docker

# Descargar e iniciar Open WebUI
# Puerto 3000 (evita conflicto con llama.cpp en :8080 y vLLM en :8000)
docker run -d \
  --name open-webui \
  --restart unless-stopped \
  --network host \
  --add-host=host.docker.internal:host-gateway \
  -v open-webui:/app/backend/data \
  -e OLLAMA_BASE_URL=http://localhost:11434 \
  ghcr.io/open-webui/open-webui:main
```

```bash
# Esperar a que arranque (30-60 segundos la primera vez)
docker logs open-webui --follow
# Esperar la línea: "Application startup complete."
# Presionar Ctrl+C para salir de los logs (el contenedor sigue corriendo)
```

```bash
# Verificar que está activo
curl -s http://localhost:3000 | grep -o '<title>[^<]*</title>'
# Salida esperada: <title>Open WebUI</title>
```

Abra desde el navegador en cualquier equipo de la red local:

```
http://192.168.1.100:3000
```

En la primera visita, Open WebUI solicita crear una cuenta de administrador local (sin conexión a internet).

> **ADVERTENCIA — Conflicto de puertos:** El puerto interno de Open WebUI es 8080, pero llama.cpp también usa 8080. Con `--network host` se expone el puerto interno directamente. Por eso este libro usa la configuración de red host **sin mapeo de puertos**, y Open WebUI escucha en el puerto 3000 mediante configuración interna. Si necesita ajustar el puerto, use `-e PORT=3000 -p 3000:3000`.

### 13C.1.2 Habilitar UFW para acceso desde red local

```bash
# Permitir acceso al puerto 3000 desde la red local [VERIFICADO EN JP 7.2]
sudo ufw allow 3000/tcp comment "Open WebUI"
sudo ufw status | grep 3000
```

---

## 13C.2 Conectar Múltiples Backends de Inferencia

Open WebUI puede conectarse simultáneamente a Ollama y a cualquier endpoint compatible con la API de OpenAI (vLLM, llama.cpp):

```bash
# Configuración multi-backend [VERIFICADO EN JP 7.2]
# IMPORTANTE: stop sin rm — el contenedor retiene el volumen de datos y usuarios
docker stop open-webui

docker run -d \
  --name open-webui \
  --restart unless-stopped \
  --network host \
  --add-host=host.docker.internal:host-gateway \
  -v open-webui:/app/backend/data \
  -e OLLAMA_BASE_URL=http://localhost:11434 \
  -e OPENAI_API_BASE_URLS="http://localhost:8000/v1;http://localhost:8080/v1" \
  -e OPENAI_API_KEYS="vllm-local;llama-local" \
  ghcr.io/open-webui/open-webui:main

docker logs open-webui --follow
```

```
# Salida esperada (extracto):
INFO:     Application startup complete.
```

Los modelos disponibles en cada motor aparecen automáticamente en el selector de modelos de la interfaz web.

**Alternativa — configurar desde la interfaz gráfica:**
- Configuración (icono engranaje) → Connections → OpenAI API
- Agregar URL: `http://localhost:8000/v1` con API Key: `vllm-local`
- Agregar URL: `http://localhost:8080/v1` con API Key: `llama-local`

---

## 13C.3 Upload de Documentos y RAG

Open WebUI incluye soporte nativo para RAG (Retrieval-Augmented Generation): sube documentos PDF, DOCX o TXT y el agente los usa como contexto.

```bash
# Verificar que el procesador de documentos está activo
docker exec open-webui ls /app/backend/data/uploads/ 2>/dev/null \
  && echo "✅ Directorio de uploads disponible" \
  || echo "⚠️  Primera inicialización en curso"
```

**Desde la interfaz web:**
1. Abrir una conversación nueva
2. Icono de clip (adjuntar) → seleccionar PDF o DOCX
3. El documento se indexa automáticamente (~30 segundos por 100 páginas)
4. Hacer preguntas sobre el documento en la misma conversación

**Configurar el motor de embeddings:**
- Configuración → Documents → Embedding Model
- Para Jetson: seleccionar `nomic-embed-text` (disponible via Ollama) — consume ~1 GB de RAM

```bash
# Instalar modelo de embeddings (si Ollama está activo)
ollama pull nomic-embed-text

# Verificar
ollama list | grep nomic
```

---

## 13C.4 Pipelines — Procesamiento Personalizado

Open WebUI soporta pipelines: interceptores Python que procesan la solicitud antes de enviarla al modelo. Útiles para: traducción automática, preprocesamiento de imágenes, filtrado de contenido, enrutamiento entre modelos.

```bash
# Crear un pipeline de traducción automática al español
mkdir -p ~/scripts/webui-pipelines

cat > ~/scripts/webui-pipelines/translate_to_spanish.py << 'EOF'
"""
Pipeline: Traduce la respuesta al español si la petición fue en inglés.
Guardar en el directorio de pipelines de Open WebUI y activar desde la interfaz.
"""
from typing import List, Union, Generator, Iterator

class Pipeline:
    def __init__(self):
        self.name = "Auto-translate to Spanish"
        self.type = "pipe"

    async def on_startup(self):
        print("Pipeline translate_to_spanish activado")

    async def pipe(
        self, user_message: str, model_id: str, messages: List[dict], body: dict
    ) -> Union[str, Generator, Iterator]:
        # Agregar instrucción al sistema para responder en español
        if "system" not in [m["role"] for m in messages]:
            messages.insert(0, {
                "role": "system",
                "content": "Responde siempre en español, independientemente del idioma de la pregunta."
            })
        yield f"Procesando con {model_id}...\n"
EOF

echo "Pipeline creado en ~/scripts/webui-pipelines/"
echo "Para activar: Settings → Pipelines → Upload pipeline file"
```

---

## 13C.5 Uso como PWA en Dispositivos Móviles

Open WebUI funciona como Progressive Web App — puede instalarse en el teléfono como una app nativa:

**Android (Chrome):**
1. Abrir `http://192.168.1.100:3000` en Chrome del teléfono
2. Menú (3 puntos) → "Añadir a pantalla de inicio"
3. Confirmar → La app aparece en el home del teléfono

**iOS (Safari):**
1. Abrir `http://192.168.1.100:3000` en Safari del iPhone
2. Botón compartir → "Añadir a inicio"
3. Confirmar → La app aparece en el home del iPhone

La app PWA funciona sin internet — usa el Jetson de la red local como backend.

---

## 13C.6 Uso de la API de Open WebUI

Open WebUI expone una API compatible con OpenAI que permite automatizar conversaciones:

```bash
# Obtener la API key desde la interfaz web:
# Settings → Account → API Keys → Create new secret key

# Guardar la key en una variable
OWUI_API_KEY="sk-xxxxxxxxxxxxxxxxxxxx"

# Listar modelos disponibles [VERIFICADO EN JP 7.2]
curl -s http://localhost:3000/api/models \
  -H "Authorization: Bearer $OWUI_API_KEY" \
  | python3 -c "import sys,json; [print(m['id']) for m in json.load(sys.stdin)['data']]"
```

```python
# Cliente Python — compatible con SDK de OpenAI
# source ~/venvs/llm/bin/activate && python3 este_script.py

from openai import OpenAI

client = OpenAI(
    base_url="http://localhost:3000/api",
    api_key="sk-xxxxxxxxxxxxxxxxxxxx"  # API key de Open WebUI
)

response = client.chat.completions.create(
    model="google/gemma-4-E4B-it",  # ID del modelo en vLLM
    messages=[
        {"role": "user", "content": "Hola, ¿qué puedes hacer por mí?"}
    ],
    max_tokens=200
)

print(response.choices[0].message.content)
```

---

## 13C.7 Scripts de Gestión (sin borrar el contenedor)

Un error común es usar `docker stop && docker rm` para "reiniciar" Open WebUI, lo que borra los usuarios y conversaciones guardados en el volumen Docker. Los scripts correctos distinguen entre **parar** (preserva datos), **eliminar** (borra todo) y **actualizar** (nueva imagen, preserva datos):

```bash
# Crear scripts de gestión [VERIFICADO EN JP 7.2]
cat > ~/scripts/webui-manage.sh << 'WEBUI_SCRIPT'
#!/bin/bash
# Uso: webui-manage.sh [start|stop|restart|status|update|kill]

case "$1" in
  start)
    docker start open-webui && echo "✅ Open WebUI iniciado"
    until curl -sf http://localhost:3000 > /dev/null; do sleep 5; done
    echo "✅ Disponible en http://$(hostname -I | awk '{print $1}'):3000"
    ;;
  stop)
    docker stop open-webui && echo "Open WebUI detenido (datos preservados)"
    ;;
  restart)
    docker restart open-webui
    until curl -sf http://localhost:3000 > /dev/null; do sleep 5; done
    echo "✅ Open WebUI reiniciado"
    ;;
  status)
    docker inspect --format='Estado: {{.State.Status}}' open-webui 2>/dev/null \
      || echo "Contenedor no existe"
    curl -sf http://localhost:3000 > /dev/null && echo "Web: accesible en :3000" || echo "Web: no responde"
    ;;
  update)
    echo "Actualizando imagen Open WebUI (preservando datos)..."
    docker pull ghcr.io/open-webui/open-webui:main
    docker stop open-webui && docker rm open-webui
    docker run -d \
      --name open-webui --restart unless-stopped \
      --network host --add-host=host.docker.internal:host-gateway \
      -v open-webui:/app/backend/data \
      -e OLLAMA_BASE_URL=http://localhost:11434 \
      -e OPENAI_API_BASE_URLS="http://localhost:8000/v1;http://localhost:8080/v1" \
      -e OPENAI_API_KEYS="vllm-local;llama-local" \
      ghcr.io/open-webui/open-webui:main
    until curl -sf http://localhost:3000 > /dev/null; do sleep 5; done
    echo "✅ Open WebUI actualizado"
    ;;
  kill)
    echo "ADVERTENCIA: Esto elimina el contenedor y preserva el volumen de datos"
    docker stop open-webui && docker rm open-webui
    echo "Contenedor eliminado (datos en volumen Docker 'open-webui' intactos)"
    ;;
  *)
    echo "Uso: $0 [start|stop|restart|status|update|kill]"
    ;;
esac
WEBUI_SCRIPT

chmod +x ~/scripts/webui-manage.sh
```

---

## 13C.8 Aliases para el Día a Día

```bash
# Agregar al ~/.bashrc [VERIFICADO EN JP 7.2]
cat >> ~/.bashrc << 'EOF'

# ── Open WebUI ───────────────────────────────────────────────────────────
alias start-webui='~/scripts/webui-manage.sh start'
alias stop-webui='~/scripts/webui-manage.sh stop'
alias restart-webui='~/scripts/webui-manage.sh restart'
alias webui-status='~/scripts/webui-manage.sh status'
alias update-webui='~/scripts/webui-manage.sh update'
alias kill-webui='~/scripts/webui-manage.sh kill'
alias webui-logs='docker logs open-webui --follow'
alias webui-url='echo "http://$(hostname -I | awk '"'"'{print $1}'"'"'):3000"'
EOF

source ~/.bashrc
```

---

## 13C.9 Monitoreo

```bash
# Ver logs en tiempo real [VERIFICADO EN JP 7.2]
docker logs open-webui --follow

# Filtrar solo errores
docker logs open-webui --follow 2>&1 | grep -i "error\|exception\|warning"

# Ver uso de recursos del contenedor
docker stats open-webui --no-stream

# Verificar que los backends están visibles desde el contenedor
docker exec open-webui curl -sf http://localhost:8000/v1/models \
  && echo "✅ vLLM visible desde el contenedor"
docker exec open-webui curl -sf http://localhost:11434/api/tags \
  && echo "✅ Ollama visible desde el contenedor"
```

---

## 13C.10 Solución de Problemas

### Puerto 3000 no accesible desde Windows

```bash
# Verificar que UFW permite el puerto 3000
sudo ufw status | grep 3000
# Si no aparece:
sudo ufw allow 3000/tcp comment "Open WebUI"

# Verificar que el contenedor está corriendo con red del host
docker inspect open-webui | python3 -c \
  "import sys,json; c=json.load(sys.stdin)[0]; print('NetworkMode:', c['HostConfig']['NetworkMode'])"
# Esperado: NetworkMode: host
```

### Los modelos de vLLM no aparecen en el selector

```bash
# Verificar que vLLM está activo antes de abrir Open WebUI
curl -sf http://localhost:8000/v1/models > /dev/null \
  && echo "✅ vLLM activo" || echo "❌ vLLM inactivo — ejecute start-qwen35 primero"

# Si vLLM acaba de iniciarse, refrescar los modelos en Open WebUI:
# Settings → Connections → Refresh (icono de recarga junto a la URL)
```

### Los usuarios o conversaciones se perdieron después de `docker rm`

```bash
# Verificar que el volumen Docker todavía existe
docker volume ls | grep open-webui
# Si aparece: docker volume ls → open-webui  local  → los datos están intactos

# Recrear el contenedor apuntando al mismo volumen
docker run -d \
  --name open-webui --restart unless-stopped \
  --network host --add-host=host.docker.internal:host-gateway \
  -v open-webui:/app/backend/data \   # ← Este volumen contiene los datos
  -e OLLAMA_BASE_URL=http://localhost:11434 \
  ghcr.io/open-webui/open-webui:main
```

> **CONSEJO:** Nunca use `docker volume rm open-webui` a menos que quiera borrar todos los usuarios, conversaciones y documentos cargados. El volumen es persistente entre reinicios del contenedor.

### Upload de documentos falla o no indexa

```bash
# Verificar que el modelo de embeddings está instalado en Ollama
ollama list | grep nomic

# Si no está instalado:
ollama pull nomic-embed-text

# Después de instalar el modelo, configurar en Open WebUI:
# Settings → Documents → Embedding Model Backend: Ollama
# Embedding Model: nomic-embed-text
```

---

## Resumen de la Parte 13C

Open WebUI es la interfaz gráfica que conecta todos los motores de inferencia del Jetson desde un navegador:

- Puerto 3000 (evita conflicto con vLLM en :8000 y llama.cpp en :8080)
- `--restart unless-stopped` es correcto — no carga modelos en GPU
- **Nunca use `docker rm open-webui` para reiniciar** — borra el contenedor pero puede perder configuraciones si el volumen no persiste; use `docker restart open-webui` o `webui-manage.sh restart`
- El volumen `open-webui` (Docker named volume) guarda usuarios, conversaciones y documentos — es persistente entre reinicios del contenedor
- Funciona como PWA en iOS y Android con el backend del Jetson

La siguiente parte (13D) cubre el tool calling avanzado: cómo implementar herramientas personalizadas que los modelos pueden invocar automáticamente, con ejemplos en Python y C++.
