# Parte 8 — Docker y NVIDIA Container Toolkit

## Introducción

Docker es el sistema de contenedores que permite ejecutar aplicaciones de forma aislada, reproducible y sin contaminar el sistema base. En el Jetson, Docker tiene un papel especialmente importante: los modelos de lenguaje más avanzados (Parte 14) se distribuyen como imágenes Docker precompiladas para ARM64+CUDA, lo que elimina la necesidad de compilar manualmente cientos de dependencias.

El NVIDIA Container Toolkit es la pieza que conecta Docker con el GPU del Jetson. Sin él, un contenedor Docker no puede acceder a CUDA ni al acelerador GPU — sería equivalente a ejecutar el modelo en CPU pura.

**Prerequisito:** Parte 1 (primer arranque) y Parte 7 (acceso SSH) completadas.

**Tiempo estimado:** 20–30 minutos.

**Al final de esta parte tendrá:**
- Docker Engine instalado y configurado para el usuario actual
- NVIDIA Container Toolkit instalado y habilitado
- Capacidad de ejecutar contenedores con acceso al GPU del Jetson
- Docker desactivado en el arranque (arquitectura de arranque limpio)

---

## 8.1 Instalar Docker Engine

Ubuntu 24.04 en el Jetson viene sin Docker instalado. Se instala desde el repositorio oficial de Docker (no desde los paquetes de Ubuntu, que suelen estar desactualizados).

### 8.1.1 Instalación desde el Repositorio Oficial de Docker [VERIFICADO EN JP 7.2]

```bash
# 1. Instalar dependencias
sudo apt update
sudo apt install -y ca-certificates curl gnupg
```

```bash
# 2. Agregar la clave GPG de Docker
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
  | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg
```

```bash
# 3. Agregar el repositorio de Docker para Ubuntu 24.04 (noble) en ARM64
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
  https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" \
  | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# 4. Actualizar e instalar Docker
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
```

```bash
# 5. Verificar la instalación
sudo docker run --rm hello-world
```

```
# Salida esperada
Hello from Docker!
This message shows that your installation appears to be working correctly.

To generate this message, Docker took the following steps:
 1. The Docker client contacted the Docker daemon...
```

### 8.1.2 Usar Docker sin sudo [VERIFICADO EN JP 7.2]

Por defecto, Docker requiere `sudo`. Agréguese al grupo `docker` para evitarlo:

```bash
# Agregar el usuario actual al grupo docker
sudo usermod -aG docker $USER

# Aplicar el cambio de grupo sin necesidad de cerrar sesión
newgrp docker

# Verificar
docker run --rm hello-world
```

```
# Salida esperada (igual que antes pero sin sudo)
Hello from Docker!
```

> **NOTA DE SEGURIDAD:** Los miembros del grupo `docker` tienen acceso root efectivo al sistema. En un servidor de producción compartido esto sería una vulnerabilidad; en el Jetson personal es el comportamiento esperado y cómodo.

### 8.1.3 Configurar Docker para el Arranque Limpio [VERIFICADO EN JP 7.2]

Siguiendo la arquitectura de arranque limpio (Parte 15 §15.0), Docker no debe iniciarse automáticamente en cada reboot:

```bash
# Desactivar Docker en el arranque
sudo systemctl disable docker
sudo systemctl disable docker.socket

# Verificar que quedó desactivado
systemctl is-enabled docker
```

```
# Salida esperada
disabled
```

> **¿Cuándo se inicia Docker entonces?** Cuando ejecute `start-qwen35`, `start-nemotron` o cualquier alias de la Sección 15.8, estos contienen `sudo systemctl start docker` al inicio. También puede iniciarlo manualmente con `sudo systemctl start docker`.

---

## 8.2 Instalar NVIDIA Container Toolkit

El NVIDIA Container Toolkit (NCT) le permite a Docker pasar el GPU del Jetson a los contenedores. Sin él, cualquier imagen que use CUDA fallará.

### 8.2.1 Instalación del NVIDIA Container Toolkit [VERIFICADO EN JP 7.2]

```bash
# 1. Agregar el repositorio de NVIDIA para el NCT
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey \
  | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg

curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list \
  | sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' \
  | sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list

# 2. Instalar el toolkit
sudo apt update
sudo apt install -y nvidia-container-toolkit
```

```bash
# 3. Configurar Docker para usar el runtime NVIDIA
sudo nvidia-ctk runtime configure --runtime=docker
```

```
# Salida esperada
INFO[0000] Loading config from /etc/docker/daemon.json
INFO[0000] Wrote updated config to /etc/docker/daemon.json
INFO[0000] It is recommended that the docker daemon be restarted.
```

```bash
# 4. Reiniciar Docker para aplicar la configuración
sudo systemctl restart docker
```

### 8.2.2 Verificar el NVIDIA Container Toolkit [VERIFICADO EN JP 7.2]

```bash
# Ejecutar un contenedor con acceso al GPU y verificar CUDA
# NOTA: En Jetson se usa --runtime nvidia, NO --gpus all (que no funciona en ARM)
sudo docker run --rm --runtime=nvidia \
  ubuntu:22.04 \
  bash -c "ls /proc/driver/nvidia/gpus/ && echo '✅ GPU accesible desde contenedor'"
```

```
# Salida esperada
0000:00:00.0
✅ GPU accesible desde contenedor
```

```bash
# Verificar CUDA dentro de un contenedor oficial de NVIDIA
docker run --rm --runtime=nvidia \
  --network host \
  ghcr.io/nvidia-ai-iot/llama_cpp:latest-jetson-orin \
  nvcc --version
```

```
# Salida esperada (tarda 2-5 min la primera vez — descarga la imagen)
nvcc: NVIDIA (R) Cuda compiler driver
Copyright (c) 2005-2024 NVIDIA Corporation
Built on ...
Cuda compilation tools, release 13.2, V13.2.91
Build cuda_13.2...
```

> **IMPORTANTE:** En el Jetson siempre se usa `--runtime nvidia` (o `--runtime=nvidia`), nunca `--gpus all`. La opción `--gpus all` es para GPUs discretas x86 y falla en la arquitectura ARM unificada del Jetson.

---

## 8.3 Arquitectura de GPU en Contenedores Jetson

Entender cómo Docker accede al GPU del Jetson evita errores comunes:

```
┌──────────────────────────────────────────────────────────┐
│                    ARQUITECTURA JETSON                    │
│                                                          │
│  ┌──────────────────────────────────────────────────┐   │
│  │         Memoria Unificada (64 GB LPDDR5)         │   │
│  │  ┌─────────────────┐  ┌─────────────────────┐  │   │
│  │  │   CPU (ARM)     │  │    GPU (Ampere)      │  │   │
│  │  │  12 núcleos     │  │    2048 CUDA cores   │  │   │
│  │  └─────────────────┘  └─────────────────────┘  │   │
│  └──────────────────────────────────────────────────┘   │
│                           │                              │
│                    /dev/nvidia0                          │
│                    /dev/nvidiactl                        │
│                    /dev/nvidia-uvm*                      │
│                           │                              │
│   ┌──────────────────────────────────────────────┐      │
│   │  Docker + NVIDIA Container Toolkit           │      │
│   │  --runtime nvidia → monta /dev/nvidia*       │      │
│   │  en el contenedor → CUDA funciona            │      │
│   └──────────────────────────────────────────────┘      │
└──────────────────────────────────────────────────────────┘
```

**Por qué no hay `nvidia-smi` en el Jetson:**
En GPUs discretas (PC/servidor), `nvidia-smi` muestra estadísticas del GPU incluyendo VRAM. En el Jetson, la memoria es unificada (CPU y GPU comparten la misma RAM física) y no existe una interfaz SMI de la misma forma. En su lugar, use:
- `jtop` — monitor integrado de Jetson (RAM total + GPU + temperatura)
- `tegrastats` — estadísticas en terminal
- `nvcc --version` dentro de contenedores — confirma que CUDA está disponible

---

## 8.4 Comandos Esenciales de Docker para el Jetson

### 8.4.1 Gestión de Imágenes

```bash
# Ver imágenes descargadas (ordenadas por tamaño)
docker images --format "table {{.Repository}}\t{{.Tag}}\t{{.Size}}" | sort -k3 -h -r

# Descargar una imagen específica
docker pull ghcr.io/nvidia-ai-iot/vllm:latest-jetson-orin

# Eliminar una imagen específica
docker rmi ghcr.io/nvidia-ai-iot/vllm:latest-jetson-orin

# Eliminar imágenes huérfanas (sin contenedor asociado, recupera espacio)
docker image prune -f

# Ver espacio total ocupado por Docker
docker system df
```

### 8.4.2 Gestión de Contenedores

```bash
# Ver contenedores activos
docker ps

# Ver todos los contenedores (incluyendo detenidos)
docker ps -a

# Ver logs de un contenedor en tiempo real
docker logs -f nombre-contenedor

# Entrar a un contenedor en ejecución
docker exec -it nombre-contenedor bash

# Detener un contenedor (gracefully, 10 seg timeout)
docker stop nombre-contenedor

# Eliminar un contenedor detenido
docker rm nombre-contenedor

# Detener y eliminar en un solo comando
docker stop nombre-contenedor && docker rm nombre-contenedor
```

### 8.4.3 Estructura de un docker run para Jetson

Todo `docker run` de modelos LLM en el Jetson sigue este patrón:

```bash
sudo docker run \
  --runtime nvidia \           # Acceso al GPU del Jetson (OBLIGATORIO)
  -d \                         # Modo daemon (en segundo plano)
  --name mi-modelo \           # Nombre para gestionar el contenedor
  --restart no \               # NO reiniciar automáticamente (arranque limpio)
  --network host \             # Compartir red del host (puerto directo al Jetson)
  --ipc host \                 # Compartir memoria IPC (necesario para vLLM)
  --shm-size 8g \              # Shared memory (vLLM necesita 8GB+)
  -v /host/path:/container/path \  # Volumen: caché de modelos (persistente)
  imagen:tag \                 # Imagen Docker a usar
  comando args                 # Comando a ejecutar dentro del contenedor
```

**Por qué `--network host`:** Al compartir la red del host, el contenedor escucha directamente en la IP del Jetson (ej: `:8000`). Sin `--network host`, necesitaría `-p 8000:8000` para publicar el puerto y usar la IP del Jetson para acceder desde otras máquinas.

---

## 8.5 Configurar el Directorio de Caché de Modelos

Los contenedores descargan los modelos en su primera ejecución. Sin un volumen persistente, los modelos se eliminan cuando se borra el contenedor. El volumen de caché evita descargar gigas repetidamente.

```bash
# Crear el directorio de caché en el NVMe (si tiene uno, ver Parte 4)
mkdir -p /data/hf-cache
mkdir -p ~/.cache/huggingface

# Crear enlace simbólico si los modelos están en NVMe
ln -sf /data/hf-cache ~/.cache/huggingface
```

```bash
# Verificar el espacio disponible
df -h /data 2>/dev/null || df -h ~
```

Todos los `docker run` de modelos deben incluir:
```bash
-v $HOME/.cache/huggingface:/root/.cache/huggingface
```

Esto monta el caché local del Jetson en la ruta donde el contenedor busca los modelos, evitando descargas redundantes.

---

## 8.6 Docker Compose: Orquestar Múltiples Contenedores

Docker Compose permite definir y lanzar stacks de múltiples contenedores con un solo comando. En el Jetson, es ideal para combinar servicios que trabajan juntos: un frontend (Open WebUI) con un backend de inferencia (Ollama), o un servidor de transcripción (faster-whisper) con un servidor TTS (kokoro-tts).

> **IMPORTANTE — Regla de oro para Jetson:** Los contenedores con GPU de inferencia (vLLM, llama.cpp, faster-whisper con CUDA) deben usar `restart: "no"` para mantener la arquitectura de arranque limpio. Los contenedores sin GPU (bases de datos, frontends, APIs ligeras) pueden usar `restart: unless-stopped`.

### 8.6.1 Instalar Docker Compose

`docker-compose-plugin` ya se instaló en §8.1.1 como parte del paquete de Docker. Verifique:

```bash
# Verificar disponibilidad de docker compose (con espacio, no guión) [VERIFICADO EN JP 7.2]
docker compose version
```

```
# Salida esperada
Docker Compose version v2.x.x
```

> **NOTA:** En sistemas antiguos existe `docker-compose` (con guión, versión 1). El plugin `docker compose` (sin guión, versión 2) es el estándar actual y el que se usa en todos los ejemplos de este libro.

### 8.6.2 Stack Básico: Open WebUI + faster-whisper

Este es el stack de productividad offline más útil para el día a día: interfaz web para LLMs y transcripción de audio. Ambos servicios son livianos y pueden coexistir con el LLM que se cargue bajo demanda.

```bash
# Crear directorio para el stack
mkdir -p ~/stacks/webui-whisper
cat > ~/stacks/webui-whisper/compose.yml << 'EOF'
name: webui-whisper

services:

  # ── Open WebUI ─────────────────────────────────────────────
  open-webui:
    image: ghcr.io/open-webui/open-webui:main
    container_name: open-webui
    restart: unless-stopped          # OK — sin GPU, solo UI
    network_mode: host
    volumes:
      - open-webui-data:/app/backend/data
    environment:
      - OPENAI_API_BASE_URL=http://localhost:8000/v1  # ← vLLM cuando esté activo
      - OLLAMA_BASE_URL=http://localhost:11434         # ← Ollama cuando esté activo
    healthcheck:
      test: ["CMD", "curl", "-sf", "http://localhost:3000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  # ── faster-whisper STT ────────────────────────────────────
  faster-whisper:
    image: dustynv/faster-whisper:r39.2.0
    container_name: faster-whisper
    restart: "no"                    # OBLIGATORIO — contenedor GPU
    runtime: nvidia
    network_mode: host
    volumes:
      - ${HOME}/.cache/huggingface:/root/.cache/huggingface
    environment:
      - WHISPER_MODEL=medium         # small para <1 GB RAM; large-v3 para máxima calidad
      - WHISPER_DEVICE=cuda
      - WHISPER_COMPUTE_TYPE=float16
      - WHISPER_LANGUAGE=es

volumes:
  open-webui-data:                   # Volumen nombrado — persiste entre reinicios
EOF
```

```bash
# Iniciar el stack
cd ~/stacks/webui-whisper
docker compose up -d

# Verificar que ambos contenedores estén activos
docker compose ps
```

```
# Salida esperada
NAME              IMAGE                                    STATUS
faster-whisper    dustynv/faster-whisper:r39.2.0          running
open-webui        ghcr.io/open-webui/open-webui:main      running (healthy)
```

```bash
# Ver logs de todos los contenedores del stack
docker compose logs -f

# Ver logs de un servicio específico
docker compose logs -f faster-whisper

# Detener el stack (sin borrar volúmenes)
docker compose down

# Detener y borrar volúmenes (¡PRECAUCIÓN: borra datos de Open WebUI!)
# docker compose down --volumes
```

### 8.6.3 Stack de Voz: faster-whisper + kokoro-tts

Para el pipeline completo STT + TTS del Parte 29:

```bash
mkdir -p ~/stacks/voice
cat > ~/stacks/voice/compose.yml << 'EOF'
name: voice-stack

services:

  # ── STT: faster-whisper ───────────────────────────────────
  faster-whisper:
    image: dustynv/faster-whisper:r39.2.0
    container_name: faster-whisper
    restart: "no"
    runtime: nvidia
    network_mode: host
    volumes:
      - ${HOME}/.cache/huggingface:/root/.cache/huggingface
    environment:
      - WHISPER_MODEL=large-v3
      - WHISPER_DEVICE=cuda
      - WHISPER_COMPUTE_TYPE=float16
      - WHISPER_LANGUAGE=es
    healthcheck:
      test: ["CMD", "curl", "-sf", "http://localhost:8000/health"]
      interval: 20s
      timeout: 10s
      retries: 5
      start_period: 120s             # Da tiempo para descargar el modelo en primer uso

  # ── TTS: kokoro ───────────────────────────────────────────
  kokoro-tts:
    image: dustynv/kokoro-tts:r39.2.0
    container_name: kokoro-tts
    restart: "no"
    runtime: nvidia
    network_mode: host
    volumes:
      - ${HOME}/.cache/huggingface:/root/.cache/huggingface
    depends_on:
      faster-whisper:
        condition: service_healthy   # Espera a que whisper esté listo antes de iniciar
EOF
```

```bash
# Iniciar el stack de voz
cd ~/stacks/voice
docker compose up -d

# Esperar a que faster-whisper esté healthy (hasta 3 min en primer uso)
echo -n "Esperando stack de voz"
until docker compose ps --format json 2>/dev/null | \
  python3 -c "import sys,json; data=json.load(sys.stdin); \
  print('ok') if all(s.get('Health','healthy')=='healthy' or s.get('State')=='running' \
  for s in data) else print('wait')" 2>/dev/null | grep -q ok; do
  echo -n "."; sleep 10
done
echo " ✅ Stack de voz activo"

# Test STT
echo "Testing STT..."
curl -s http://localhost:8000/health && echo "✅ faster-whisper :8000 OK"

# Test TTS
echo "Testing TTS..."
curl -s http://localhost:8880/health && echo "✅ kokoro-tts :8880 OK"
```

### 8.6.4 Comandos Esenciales de Docker Compose

```bash
# ── Gestión del stack ─────────────────────────────────────────────────
# Iniciar todos los servicios (en segundo plano)
docker compose up -d

# Detener todos los servicios (contenedores quedan parados, no borrados)
docker compose down

# Reiniciar un servicio específico sin tocar los otros
docker compose restart faster-whisper

# Escalar (no aplica para GPU en Jetson — solo 1 instancia por GPU)
# docker compose up -d --scale faster-whisper=1

# ── Inspección ───────────────────────────────────────────────────────
# Estado de los servicios
docker compose ps

# Logs de todos los servicios (últimas 50 líneas + streaming)
docker compose logs --tail=50 -f

# Uso de recursos del stack
docker compose stats

# ── Actualizar imágenes ──────────────────────────────────────────────
# Descargar versiones más recientes de las imágenes
docker compose pull

# Reiniciar con las nuevas imágenes
docker compose up -d

# ── Limpieza ─────────────────────────────────────────────────────────
# Borrar contenedores e imágenes del stack (mantiene volúmenes nombrados)
docker compose down --rmi all

# Borrar TODO incluyendo datos (¡DESTRUCTIVO — requiere confirmación mental!)
# docker compose down --rmi all --volumes
```

### 8.6.5 Estructura de un compose.yml para el Jetson

```yaml
# Plantilla canónica para servicios con GPU en Jetson AGX Orin JP 7.2
name: mi-stack

services:

  mi-servicio-gpu:
    image: ghcr.io/nvidia-ai-iot/vllm:latest-jetson-orin  # imagen ARM64+CUDA
    container_name: mi-servicio-gpu
    restart: "no"              # SIEMPRE "no" para servicios de inferencia GPU
    runtime: nvidia            # OBLIGATORIO — equivalente a --runtime nvidia
    network_mode: host         # Compartir red del host (sin mapeo de puertos)
    shm_size: "8g"             # Shared memory para vLLM
    ipc: host                  # Para PyTorch multiprocessing
    volumes:
      - ${HOME}/.cache/huggingface:/root/.cache/huggingface
    environment:
      - VARIABLE=valor
    command: bash -c "cd /opt && source venv/bin/activate && vllm serve ..."

  mi-servicio-cpu:
    image: postgres:16-alpine  # Imagen estándar — sin GPU
    container_name: mi-db
    restart: unless-stopped    # OK para servicios sin GPU
    volumes:
      - postgres-data:/var/lib/postgresql/data
    environment:
      - POSTGRES_PASSWORD=segura
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U postgres"]
      interval: 10s
      timeout: 5s
      retries: 5

volumes:
  postgres-data:               # Volumen nombrado — persiste entre reinicios del contenedor
```

> **Regla de la coma con GPU:** Si el servicio toca `/dev/nvidia*`, usa `restart: "no"` y `runtime: nvidia`. Si no tiene GPU, puede usar `restart: unless-stopped`.

### 8.6.6 Aliases para Gestión de Stacks

```bash
# Agregar al ~/.bashrc [VERIFICADO EN JP 7.2]
cat >> ~/.bashrc << 'EOF'

# ── Docker Compose stacks ────────────────────────────────────────────
alias start-voice-stack='cd ~/stacks/voice && docker compose up -d && cd -'
alias stop-voice-stack='cd ~/stacks/voice && docker compose down && cd -'
alias start-webui-stack='cd ~/stacks/webui-whisper && docker compose up -d && cd -'
alias stop-webui-stack='cd ~/stacks/webui-whisper && docker compose down && cd -'
alias stack-status='docker compose -f ~/stacks/voice/compose.yml ps 2>/dev/null; docker compose -f ~/stacks/webui-whisper/compose.yml ps 2>/dev/null'
alias stack-logs='docker compose -f ~/stacks/voice/compose.yml logs --tail=30 2>/dev/null'
EOF

source ~/.bashrc
```

---

## 8.7 Verificación Final del Capítulo

```bash
# Verificación completa de Docker + NVIDIA Container Toolkit [VERIFICADO EN JP 7.2]
echo "╔═════════════════════════════════════════════════════╗"
echo "║    VERIFICACIÓN PARTE 8 — DOCKER + NVIDIA NCT      ║"
echo "╚═════════════════════════════════════════════════════╝"

echo ""
echo "── Docker Engine ──"
docker version --format "  ✅ Docker {{.Server.Version}} ({{.Server.Os}}/{{.Server.Arch}})" \
  2>/dev/null || echo "  ❌ Docker no accesible (¿ejecutar sudo systemctl start docker?)"

echo ""
echo "── Grupo Docker ──"
groups | grep -q docker \
  && echo "  ✅ Usuario en grupo docker (sin sudo necesario)" \
  || echo "  ⚠️  Usuario NO en grupo docker — ejecute: sudo usermod -aG docker \$USER"

echo ""
echo "── Docker en arranque ──"
systemctl is-enabled docker 2>/dev/null | grep -q "disabled" \
  && echo "  ✅ Docker desactivado en boot (arranque limpio)" \
  || echo "  ⚠️  Docker activo en boot — ejecute: sudo systemctl disable docker"

echo ""
echo "── NVIDIA Container Toolkit ──"
nvidia-ctk --version 2>/dev/null \
  && echo "  ✅ nvidia-ctk instalado" \
  || echo "  ❌ nvidia-ctk no instalado — ver Sección 8.2"

echo ""
echo "── Runtime NVIDIA en Docker ──"
docker info 2>/dev/null | grep -q "nvidia" \
  && echo "  ✅ Runtime nvidia configurado" \
  || echo "  ⚠️  Runtime nvidia no detectado — ejecute: sudo nvidia-ctk runtime configure --runtime=docker"

echo ""
echo "── Test GPU en contenedor ──"
docker run --rm --runtime=nvidia ubuntu:22.04 \
  ls /proc/driver/nvidia/gpus/ 2>/dev/null \
  && echo "  ✅ GPU accesible desde contenedor" \
  || echo "  ❌ GPU no accesible — verificar instalación NCT"

echo ""
echo "── Imágenes NVIDIA disponibles ──"
docker images | grep -E "nvidia-ai-iot|dustynv" \
  | awk '{printf "  ✅ %s:%s (%s)\n", $1, $2, $7}' \
  || echo "  ℹ️  Sin imágenes NVIDIA descargadas todavía (se descargan con los modelos)"

echo ""
echo "════════════════════════════════════════════════════"
```

```
# Salida esperada
── Docker Engine ──
  ✅ Docker 27.x.x (linux/arm64)

── Grupo Docker ──
  ✅ Usuario en grupo docker (sin sudo necesario)

── Docker en arranque ──
  ✅ Docker desactivado en boot (arranque limpio)

── NVIDIA Container Toolkit ──
  nvidia-ctk version 1.x.x
  ✅ nvidia-ctk instalado

── Runtime NVIDIA en Docker ──
  ✅ Runtime nvidia configurado

── Test GPU en contenedor ──
  0000:00:00.0
  ✅ GPU accesible desde contenedor

── Imágenes NVIDIA disponibles ──
  ℹ️  Sin imágenes NVIDIA descargadas todavía (se descargan con los modelos)
```

> **Próximo paso:** Con Docker y el NVIDIA Container Toolkit configurados, la Parte 12 puede ejecutar los contenedores de inferencia de NVIDIA. Antes de continuar con los capítulos de modelos, la Parte 16 cubre el troubleshooting de los errores más comunes.
