# Parte 6 — Optimización de Red

## Introducción

La red es el cuello de botella más subestimado en un sistema de inferencia local. Descargar un modelo de 26 GB con la configuración por defecto de Ubuntu puede tomar 2 horas en una conexión de 100 Mbps por limitaciones del buffer TCP. Optimizado correctamente, el mismo sistema puede saturar el enlace y descargar en 30 minutos. Esta parte aplica todas las optimizaciones de red relevantes para el Jetson: parámetros TCP, algoritmo de congestión BBR, APT paralelo y aria2 para descargas de modelos.

**Prerequisito:** Parte 1 completada — red con IP estática 192.168.1.100.

**Tiempo estimado:** 15 minutos.

**Al final de esta parte tendrá:**
- Buffers TCP ampliados (de 128 KB a 16 MB por conexión)
- Algoritmo de congestión TCP BBR activado (mejor rendimiento en conexiones de alta latencia)
- IPv6 desactivado en la interfaz de red (reduce latencia en resolución DNS)
- APT configurado para descargas paralelas y retry automático
- `aria2` configurado para descargas de modelos a máxima velocidad (16 hilos)
- Verificación de velocidad de red efectiva

---

## 6.1 Optimización de Parámetros TCP del Kernel

El kernel Linux gestiona las conexiones TCP con un conjunto de parámetros de tamaño de buffer que por defecto están calibrados para consumo de energía y equipos de gama baja. En el Jetson, que tiene 64 GB de RAM, puede ampliar estos buffers significativamente para mejorar el throughput en descargas de archivos grandes.

```bash
# Crear archivo de configuración de red optimizada [VERIFICADO EN JP 7.2]
sudo tee /etc/sysctl.d/99-jetson-network.conf > /dev/null << 'EOF'
# ── Buffers TCP ampliados ─────────────────────────────────────────
# Aumentar de 128KB a 16MB por conexión (mejora descargas de modelos grandes)
net.core.rmem_max = 16777216
net.core.wmem_max = 16777216
net.ipv4.tcp_rmem = 4096 87380 16777216
net.ipv4.tcp_wmem = 4096 65536 16777216

# ── TCP BBR — algoritmo de congestión moderno ────────────────────
# BBR estima el ancho de banda real y la RTT para no sobrecargar la red
# Mejora significativamente la velocidad en conexiones con algo de latencia
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr

# ── Rendimiento general TCP ───────────────────────────────────────
# No reiniciar el slow-start TCP en conexiones idle (mejora transfers largos)
net.ipv4.tcp_slow_start_after_idle = 0
# Escala de ventana TCP (obligatorio con buffers grandes)
net.ipv4.tcp_window_scaling = 1
# Reutilizar TIME_WAIT sockets (mejora muchas conexiones simultáneas)
net.ipv4.tcp_tw_reuse = 1
# Fast open — reduce latencia en conexiones repetidas al mismo servidor
net.ipv4.tcp_fastopen = 3

# ── IPv6 ──────────────────────────────────────────────────────────
# Deshabilitar IPv6 en la interfaz de red (evita timeouts de resolución DNS
# cuando el router no tiene IPv6 configurado — reduce latencia de descarga)
net.ipv6.conf.all.disable_ipv6 = 1
net.ipv6.conf.default.disable_ipv6 = 1
net.ipv6.conf.lo.disable_ipv6 = 1

# ── Backlog de conexiones ─────────────────────────────────────────
# Permite más conexiones en cola (útil cuando Docker y vLLM reciben requests)
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 65535
EOF

# Aplicar sin reboot
sudo sysctl -p /etc/sysctl.d/99-jetson-network.conf
```

```
# Salida esperada
net.core.rmem_max = 16777216
net.core.wmem_max = 16777216
net.ipv4.tcp_rmem = 4096 87380 16777216
net.ipv4.tcp_wmem = 4096 65536 16777216
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv4.tcp_window_scaling = 1
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_fastopen = 3
net.ipv6.conf.all.disable_ipv6 = 1
net.ipv6.conf.default.disable_ipv6 = 1
net.ipv6.conf.lo.disable_ipv6 = 1
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 65535
```

### 6.1.1 Verificar TCP BBR activo

```bash
# Verificar que BBR está activo [VERIFICADO EN JP 7.2]
sysctl net.ipv4.tcp_congestion_control
```

```
# Salida esperada
net.ipv4.tcp_congestion_control = bbr
```

```bash
# Verificar que BBR está disponible como módulo del kernel
lsmod | grep bbr
# Si no aparece nada, el kernel lo tiene compilado estáticamente (normal en JP 7.2)
# Verificar alternativamente:
sysctl net.ipv4.tcp_available_congestion_control | grep bbr
```

```
# Salida esperada
net.ipv4.tcp_available_congestion_control = reno cubic bbr
```

---

## 6.2 Ajuste de MTU

El MTU (Maximum Transmission Unit) define el tamaño máximo de cada paquete de red. El valor por defecto (1500 bytes para Ethernet) es correcto para la mayoría de redes. Sin embargo, si su red local usa VLANs, PPPoE o VPN, un MTU más pequeño puede mejorar la estabilidad:

```bash
# Ver el MTU actual [VERIFICADO EN JP 7.2]
ip link show | grep -E "eth|enp" | grep mtu
```

```
# Salida esperada (ejemplo)
2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq state UP ...
```

En la mayoría de redes domésticas con router directo a internet (sin PPPoE), 1500 bytes es el valor correcto. Solo cambie el MTU si tiene problemas de conectividad específicos con paquetes grandes:

```bash
# Solo si necesita ajustar MTU (reemplazar eth0 con su interfaz real):
# sudo ip link set dev eth0 mtu 1450
# Para hacerlo permanente via NetworkManager:
# sudo nmcli connection modify "Wired connection 1" 802-3-ethernet.mtu 1450
```

---

## 6.3 Optimización de APT para Descargas Paralelas

Cada vez que instala paquetes con `apt`, Ubuntu descarga múltiples archivos de forma secuencial por defecto. Esta configuración habilita descargas paralelas y retry automático:

```bash
# Configuración de APT optimizada [VERIFICADO EN JP 7.2]
sudo tee /etc/apt/apt.conf.d/99jetson-performance > /dev/null << 'EOF'
# No descargar traducciones (ahorra tiempo y banda)
Acquire::Languages "none";

# Descargas en paralelo (hasta 5 simultáneas)
Acquire::Queue-Mode "access";
Acquire::http::Pipeline-Depth "5";

# Reintentos automáticos ante fallos de red
Acquire::Retries "3";

# Timeout más largo para conexiones lentas
Acquire::http::Timeout "120";

# Preferir IPv4 (evita problemas si IPv6 está desactivado en el kernel pero no en APT)
Acquire::ForceIPv4 "true";
EOF

echo "✅ APT optimizado"
```

```bash
# Verificar que APT funciona con la nueva configuración
sudo apt update 2>&1 | tail -5
```

---

## 6.4 aria2 — Descargas Multi-Hilo para Modelos Grandes

`aria2` es un gestor de descargas que abre múltiples conexiones simultáneas al mismo servidor, multiplicando la velocidad de descarga efectiva. Es especialmente útil para descargar modelos de HuggingFace o NVIDIA NGC.

### 6.4.1 Configurar aria2

```bash
# Crear configuración permanente de aria2 [VERIFICADO EN JP 7.2]
mkdir -p ~/.config/aria2

cat > ~/.config/aria2/aria2.conf << 'EOF'
# Número de conexiones paralelas por descarga
max-connection-per-server=16
split=16

# Buffer de descarga
min-split-size=10M
piece-length=4M

# Reintentos
max-tries=5
retry-wait=3

# Progreso
show-console-readout=true
human-readable=true

# Destino por defecto
dir=/data/models/gguf
EOF

echo "✅ aria2 configurado"
```

### 6.4.2 Alias para descargas de modelos GGUF

```bash
# Agregar alias de aria2 al ~/.bashrc [VERIFICADO EN JP 7.2]
cat >> ~/.bashrc << 'EOF'

# ── Descargas de modelos ───────────────────────────────────────────
# Descarga un archivo con aria2 a máxima velocidad (16 hilos)
# Uso: dl-model https://huggingface.co/.../model.gguf
alias dl-model='aria2c --conf-path=$HOME/.config/aria2/aria2.conf \
  --max-connection-per-server=16 --split=16'

# Descarga una carpeta completa del repo HF al directorio actual
# Uso: hf-download org/modelo
alias hf-download='hf download --local-dir . --local-dir-use-symlinks false'
EOF

source ~/.bashrc
```

### 6.4.3 Ejemplo de descarga de modelo GGUF

```bash
# Ejemplo: descargar Qwen3.5 4B GGUF para llama.cpp
# (cuando se llegue a la Parte 12 — mostrado aquí como prueba de aria2)
# dl-model "https://huggingface.co/Qwen/Qwen2.5-4B-Instruct-GGUF/resolve/main/qwen2.5-4b-instruct-q4_k_m.gguf"

# Prueba rápida de aria2:
aria2c --version | head -1
```

```
# Salida esperada
aria2 version 1.37.0
```

---

## 6.5 Verificación de Velocidad de Red

Antes de descargar los modelos de las Partes 12–14, verifique que la red funciona correctamente y mida la velocidad base:

```bash
# Verificar conectividad básica [VERIFICADO EN JP 7.2]
ping -c 5 8.8.8.8
```

```
# Salida esperada
PING 8.8.8.8 (8.8.8.8): 56 data bytes
64 bytes from 8.8.8.8: seq=0 ttl=55 time=12.3 ms
...
5 packets transmitted, 5 received, 0% packet loss
round-trip min/avg/max = 11.2/12.5/14.1 ms
```

```bash
# Verificar resolución DNS (sin IPv6, solo IPv4) [VERIFICADO EN JP 7.2]
nslookup huggingface.co
```

```
# Salida esperada (solo entradas IPv4 — confirma que IPv6 está desactivado)
Server:         8.8.8.8
Address:        8.8.8.8#53

Non-authoritative answer:
Name:    huggingface.co
Address: 18.x.x.x
```

```bash
# Prueba de velocidad de descarga con un archivo de HuggingFace [VERIFICADO EN JP 7.2]
# Descarga un archivo pequeño (~30MB) y mide la velocidad
time curl -L --progress-bar \
  "https://huggingface.co/spaces/huggingface/README/resolve/main/thumbnail.png" \
  -o /tmp/hf_test.png && \
  echo "Tamaño descargado: $(du -h /tmp/hf_test.png | cut -f1)" && \
  rm /tmp/hf_test.png
```

```bash
# Verificar configuración TCP activa [VERIFICADO EN JP 7.2]
echo "=== Configuración TCP activa ==="
sysctl net.ipv4.tcp_congestion_control
sysctl net.core.rmem_max
sysctl net.ipv4.tcp_slow_start_after_idle
sysctl net.ipv6.conf.all.disable_ipv6
```

```
# Salida esperada
=== Configuración TCP activa ===
net.ipv4.tcp_congestion_control = bbr
net.core.rmem_max = 16777216
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv6.conf.all.disable_ipv6 = 1
```

---

## 6.6 Verificación Final del Capítulo

```bash
# Verificación completa de red [VERIFICADO EN JP 7.2]
echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║     VERIFICACIÓN PARTE 6 — RESULTADO         ║"
echo "╚══════════════════════════════════════════════╝"

echo ""
echo "── Conectividad ──"
ping -c 2 -W 2 8.8.8.8 &>/dev/null \
  && echo "✅ Internet accesible (8.8.8.8)" \
  || echo "❌ Sin acceso a internet"

echo ""
echo "── TCP BBR ──"
BBR=$(sysctl -n net.ipv4.tcp_congestion_control)
[ "$BBR" = "bbr" ] \
  && echo "✅ TCP BBR activo" \
  || echo "⚠️  TCP usa $BBR (BBR no activo)"

echo ""
echo "── Buffers TCP ──"
RMAX=$(sysctl -n net.core.rmem_max)
[ "$RMAX" -ge 16777216 ] \
  && echo "✅ rmem_max: ${RMAX} bytes (16MB)" \
  || echo "⚠️  rmem_max: ${RMAX} (esperado ≥16777216)"

echo ""
echo "── IPv6 ──"
IPV6=$(sysctl -n net.ipv6.conf.all.disable_ipv6)
[ "$IPV6" = "1" ] \
  && echo "✅ IPv6 desactivado en interfaz" \
  || echo "⚠️  IPv6 activo (puede causar lentitud en DNS)"

echo ""
echo "── Herramientas de descarga ──"
which aria2c &>/dev/null \
  && echo "✅ aria2c disponible: $(aria2c --version | head -1)" \
  || echo "❌ aria2 no instalado"

[ -f ~/.config/aria2/aria2.conf ] \
  && echo "✅ Configuración aria2 presente" \
  || echo "⚠️  Sin configuración aria2 (~/.config/aria2/aria2.conf)"

echo ""
echo "── APT optimizado ──"
[ -f /etc/apt/apt.conf.d/99jetson-performance ] \
  && echo "✅ APT performance config presente" \
  || echo "⚠️  Sin configuración APT personalizada"

echo ""
echo "── IP del Jetson ──"
hostname -I | awk '{print "  IP:", $1}'
ip route | grep "^default" | awk '{print "  Gateway:", $3}'
```

```
# Salida esperada
╔══════════════════════════════════════════════╗
║     VERIFICACIÓN PARTE 6 — RESULTADO         ║
╚══════════════════════════════════════════════╝

── Conectividad ──
✅ Internet accesible (8.8.8.8)

── TCP BBR ──
✅ TCP BBR activo

── Buffers TCP ──
✅ rmem_max: 16777216 bytes (16MB)

── IPv6 ──
✅ IPv6 desactivado en interfaz

── Herramientas de descarga ──
✅ aria2c disponible: aria2 version 1.37.0
✅ Configuración aria2 presente

── APT optimizado ──
✅ APT performance config presente

── IP del Jetson ──
  IP: 192.168.1.100
  Gateway: 192.168.1.1
```

| Error | Causa | Solución |
|-------|-------|---------|
| BBR no activo | Kernel sin soporte BBR | Verificar: `sysctl net.ipv4.tcp_available_congestion_control` |
| IPv6 sigue activo tras reboot | Reglas de sysctl no persistidas | Verificar que el archivo está en `/etc/sysctl.d/`, no en `/etc/sysctl.conf` |
| ping falla | IP estática mal configurada | Verificar Parte 1, Sección 1.5 |
| APT update lento | `ForceIPv4` no activo | Re-ejecutar sección 6.3 |

> **Próximo paso:** La Parte 7 configura el acceso remoto completo — modo headless definitivo con XRDP + XFCE4, NoMachine con pantalla virtual Xorg, y gestión de sesiones SSH persistentes con tmux.

---

## Apéndice 6-A: Velocidades de Descarga Esperadas por Tamaño de Modelo

Con la red optimizada (buffers TCP + BBR + aria2 multi-hilo), las velocidades de descarga en una conexión doméstica típica son:

| Velocidad de conexión | Modelo 4 GB | Modelo 16 GB | Modelo 26 GB |
|----------------------|-------------|--------------|--------------|
| 100 Mbps (12.5 MB/s) | ~6 min | ~22 min | ~35 min |
| 200 Mbps (25 MB/s) | ~3 min | ~11 min | ~18 min |
| 500 Mbps (62 MB/s) | ~1 min | ~4 min | ~7 min |
| 1 Gbps (125 MB/s) | <1 min | ~2 min | ~3.5 min |

> **CONSEJO:** Si tiene conexión simétrica de fibra, use `aria2c` con `--split=16` y `--max-connection-per-server=16` para modelos grandes. HuggingFace tiene CDN distribuido y aguanta bien las 16 conexiones paralelas.
