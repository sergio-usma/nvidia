# Parte 2 — Configuración Base del Sistema

## Introducción

Esta parte configura el Jetson para trabajo completamente remoto y sin monitor: modo headless, escritorio remoto desde Windows, acceso gráfico vía NoMachine y GitHub SSH. Al final, el Jetson nunca más necesitará un monitor físico — todo se administra desde Windows vía SSH, XRDP o NoMachine.

**Prerequisito:** Parte 1 completada — Ubuntu 24.04 instalado, SSH funcionando, IP 192.168.1.100.

**Tiempo estimado:** 30–45 minutos.

**Al final de esta parte tendrá:**
- Modo headless activo (arranque sin GUI local)
- Display virtual 1920×1080 para sesiones gráficas remotas
- Escritorio remoto desde Windows vía XRDP (puerto 3389, cliente `mstsc`)
- Acceso gráfico completo vía NoMachine (puerto 4000)
- Clave SSH de GitHub configurada en el Jetson
- Variables de entorno críticas (`HF_TOKEN`, `CUDA_HOME`, `TORCH_CUDA_ARCH_LIST`) disponibles para Docker y systemd

---

## 2.1 Modo Headless — Arranque sin Entorno Gráfico Local

Por defecto, Ubuntu 24.04 arranca en `graphical.target`, lo que inicia el servidor gráfico GDM3, el entorno de escritorio GNOME y Wayland. Esto consume aproximadamente 1.5–2 GB de RAM innecesariamente cuando el Jetson opera sin monitor físico. El modo headless elimina esa carga y arranca en `multi-user.target` (solo servicios de red y consola).

> **IMPORTANTE:** La Parte 15 (Sección 15.0) documenta `multi-user.target` como la arquitectura de arranque limpio recomendada para producción. Este paso lo establece desde el principio. NoMachine sigue funcionando perfectamente en modo headless — genera su sesión gráfica virtualmente en el servidor y la envía a su PC.

### 2.1.1 Deshabilitar Wayland y configurar GDM3

Ubuntu 24.04 usa Wayland por defecto, pero XRDP y NoMachine necesitan X11. Antes de pasar a `multi-user.target` completamente, configure GDM3 para que cuando lo inicie manualmente use X11:

```bash
# Deshabilitar Wayland en GDM3 [VERIFICADO EN JP 7.2]
sudo tee /etc/gdm3/custom.conf > /dev/null << 'EOF'
[daemon]
AutomaticLoginEnable=true
AutomaticLogin=jetson
WaylandEnable=false

[security]

[xdmcp]

[chooser]

[debug]
EOF
```

```bash
# Establecer variables globales de sesión X11 [VERIFICADO EN JP 7.2]
# Agregar al final de /etc/environment
sudo tee -a /etc/environment << 'EOF'
QT_QPA_PLATFORM=xcb
GDK_BACKEND=x11
XDG_SESSION_TYPE=x11
EOF
```

### 2.1.2 Display virtual 1920×1080 (Xorg Dummy)

Sin monitor físico conectado, el framebuffer del Jetson se limita a 640×480. El driver `dummy` crea un display virtual de 1920×1080 en RAM que XRDP y NoMachine pueden usar:

```bash
# Instalar driver Xorg dummy [VERIFICADO EN JP 7.2]
sudo apt install -y xserver-xorg-video-dummy
sudo mkdir -p /etc/X11/xorg.conf.d/

# Crear configuración de display virtual
sudo tee /etc/X11/xorg.conf.d/30-tegra-headless.conf > /dev/null << 'EOF'
Section "Device"
    Identifier  "Tegra"
    Driver      "nvidia"
    Option      "AllowEmptyInitialConfiguration" "true"
    Option      "UseDisplayDevice" "none"
EndSection

Section "Monitor"
    Identifier  "Monitor0"
    HorizSync   28.0-80.0
    VertRefresh 48.0-75.0
    Modeline    "1920x1080" 148.50 1920 2008 2052 2200 1080 1084 1089 1125 +hsync +vsync
EndSection

Section "Screen"
    Identifier  "Screen0"
    Device      "Tegra"
    Monitor     "Monitor0"
    DefaultDepth 24
    SubSection "Display"
        Depth    24
        Virtual  1920 1080
    EndSubSection
EndSection
EOF
```

### 2.1.3 Establecer multi-user.target como target de arranque

```bash
# Arrancar en modo texto (sin GUI local) [VERIFICADO EN JP 7.2]
sudo systemctl set-default multi-user.target
```

```
# Salida esperada
Created symlink /etc/systemd/system/default.target → /lib/systemd/system/multi-user.target
```

```bash
# Reiniciar para aplicar
sudo reboot
```

Espere 30 segundos y verifique desde Windows:

```powershell
# En Windows PowerShell
ping 192.168.1.100    # debe responder
ssh jetson            # debe conectar sin contraseña
```

```bash
# Confirmar que el target es correcto [VERIFICADO EN JP 7.2]
systemctl get-default
```

```
# Salida esperada
multi-user.target
```

---

## 2.2 XRDP — Escritorio Remoto desde Windows

XRDP permite conectar al escritorio del Jetson usando el cliente de escritorio remoto nativo de Windows (`mstsc`), sin instalar software adicional. En Ubuntu 24.04, XRDP requiere un fix específico para el problema de pantalla negra que afecta a casi todas las instalaciones.

### 2.2.1 Instalar XRDP

```bash
# Instalar XRDP [VERIFICADO EN JP 7.2]
sudo apt install -y xrdp

# Agregar xrdp al grupo ssl-cert (necesario para acceso a certificados TLS)
sudo adduser xrdp ssl-cert
```

### 2.2.2 Fix de pantalla negra — startwm.sh

El problema de pantalla negra en XRDP con Ubuntu 24.04 ocurre porque el script de inicio de sesión no establece las variables de entorno necesarias para GNOME. La solución es reescribir `/etc/xrdp/startwm.sh`:

```bash
# Reescribir el script de inicio de sesión XRDP [VERIFICADO EN JP 7.2]
sudo tee /etc/xrdp/startwm.sh > /dev/null << 'EOF'
#!/bin/sh
# xrdp session startup — Ubuntu 24.04 / Jetson AGX Orin JP 7.2

if test -r /etc/profile; then
    . /etc/profile
fi

# Variables críticas que resuelven el black screen en Ubuntu 24.04
export DESKTOP_SESSION=ubuntu
export GNOME_SHELL_SESSION_MODE=ubuntu
export XDG_CURRENT_DESKTOP=ubuntu:GNOME

# Limpiar variables que interfieren entre sesiones
unset DBUS_SESSION_BUS_ADDRESS
unset XDG_RUNTIME_DIR

test -x /etc/X11/Xsession && exec /etc/X11/Xsession
exec /bin/sh /etc/X11/Xsession
EOF

sudo chmod +x /etc/xrdp/startwm.sh
```

```bash
# Archivos de configuración de sesión del usuario [VERIFICADO EN JP 7.2]
cat > ~/.xsessionrc << 'EOF'
export XDG_SESSION_TYPE=x11
export GNOME_SHELL_SESSION_MODE=ubuntu
export XDG_CURRENT_DESKTOP=ubuntu:GNOME
export XDG_CONFIG_DIRS=/etc/xdg/xdg-ubuntu:/etc/xdg
export DESKTOP_SESSION=ubuntu
unset DBUS_SESSION_BUS_ADDRESS
unset XDG_RUNTIME_DIR
EOF

cat > ~/.xsession << 'EOF'
#!/bin/bash
unset DBUS_SESSION_BUS_ADDRESS
unset XDG_RUNTIME_DIR
export GNOME_SHELL_SESSION_MODE=ubuntu
export XDG_CURRENT_DESKTOP=ubuntu:GNOME
export DESKTOP_SESSION=ubuntu
export XDG_SESSION_TYPE=x11
exec /usr/bin/gnome-session --session=ubuntu
EOF
chmod +x ~/.xsession
```

### 2.2.3 Fix de permisos PolicyKit (colord)

Ubuntu 24.04 usa un formato nuevo para las reglas de PolicyKit que evita advertencias de permisos en GNOME:

```bash
# Crear regla PolicyKit para color management [VERIFICADO EN JP 7.2]
sudo mkdir -p /etc/polkit-1/rules.d/

sudo tee /etc/polkit-1/rules.d/45-allow-colord.rules > /dev/null << 'EOF'
polkit.addRule(function(action, subject) {
    if (action.id.indexOf("org.freedesktop.color-manager.") === 0) {
        return polkit.Result.YES;
    }
});
EOF
```

> **NOTA:** Ubuntu 24.04 usa el formato `.rules` (JavaScript) en lugar del `.pkla` (INI) de Ubuntu 22.04. Si ve tutoriales para JP 6.2 que crean archivos `.pkla`, ignore esa parte — no funciona en Ubuntu 24.04.

### 2.2.4 Habilitar y verificar XRDP

```bash
# Habilitar y arrancar XRDP [VERIFICADO EN JP 7.2]
sudo systemctl enable xrdp
sudo systemctl restart xrdp

# Verificar estado
sudo systemctl status xrdp | grep -E "Active|Loaded"

# Confirmar que escucha en el puerto 3389
sudo ss -tlnp | grep 3389
```

```
# Salida esperada
     Loaded: loaded (/lib/systemd/system/xrdp.service; enabled; ...)
     Active: active (running) since ...
LISTEN   0   10    0.0.0.0:3389    0.0.0.0:*    users:(("xrdp",pid=...))
```

### 2.2.5 Conectar desde Windows

Abra el cliente de escritorio remoto de Windows:
- Presione `Win+R` → escriba `mstsc` → Enter
- En la casilla "Equipo": escriba `192.168.1.100`
- Usuario: `jetson`
- Contraseña: la que configuró en el wizard OEM

**Si aparece pantalla negra al conectar:**

```bash
# Matar sesiones GNOME huérfanas (causa más común del black screen)
sudo pkill -u jetson gnome-session 2>/dev/null || true
sudo systemctl restart xrdp
# Vuelva a conectar desde mstsc
```

**Alternativa más estable — XFCE4 en lugar de GNOME:**

Si el escritorio GNOME sigue dando problemas con XRDP, XFCE4 es mucho más liviano y estable para uso remoto:

```bash
# Instalar XFCE4 (escritorio ligero, ideal para acceso remoto) [VERIFICADO EN JP 7.2]
sudo apt install -y xfce4 xfce4-goodies
echo 'exec startxfce4' > ~/.xsession
chmod +x ~/.xsession
sudo systemctl restart xrdp
# Reconectar desde mstsc
```

---

## 2.3 NoMachine — Acceso Gráfico Remoto de Alta Calidad

NoMachine es una solución de escritorio remoto que supera a XRDP en fluidez y capacidad de compresión. Soporta audio, transferencia de archivos y funciona mejor con conexiones de red lentas. Es la opción recomendada para trabajo gráfico intensivo desde Windows.

### 2.3.1 Instalar NoMachine Server

```bash
# Verificar la última versión disponible para arm64 en:
# downloads.nomachine.com/download/?id=30&platform=linux&distro=arm
# Al momento de JP 7.2: versión 9.7.x para arm64

cd ~/Downloads

# Descargar directamente si hay conexión desde el Jetson:
wget -q --show-progress \
  "https://web9001.nomachine.com/download/9.7/Arm/nomachine_9.7.3_1_arm64.deb" \
  -O nomachine_arm64.deb

# O bien, descargar en Windows y subir al Jetson via scp:
# [En Windows PowerShell]: scp C:\Users\sergi\Downloads\nomachine_9.7.3_1_arm64.deb jetson:~/Downloads/

# Instalar
sudo dpkg -i ~/Downloads/nomachine_*.deb
sudo apt --fix-broken install -y
```

```
# Salida esperada
Selecting previously unselected package nomachine.
(Reading database ... )
Preparing to unpack nomachine_9.7.3_1_arm64.deb ...
Unpacking nomachine (9.7.3-1) ...
Setting up nomachine (9.7.3-1) ...
```

### 2.3.2 Iniciar y verificar el servidor NoMachine

```bash
# Iniciar el servidor NX [VERIFICADO EN JP 7.2]
sudo /usr/NX/bin/nxserver --start

# Verificar que está corriendo en el puerto 4000
sudo /usr/NX/bin/nxserver --status
```

```
# Salida esperada
NX> 111 NXSERVER - Version 9.7.3 ...
NX> 500 Running server at port: 4000
```

```bash
# Habilitar arranque automático [VERIFICADO EN JP 7.2]
sudo systemctl enable nxserver 2>/dev/null || \
  sudo /usr/NX/bin/nxserver --startup
```

### 2.3.3 Configurar sesión XFCE4 virtual para NoMachine

NoMachine en modo headless necesita un entorno gráfico virtual. XFCE4 es la opción recomendada por su bajo consumo de RAM:

```bash
# Instalar XFCE4 si no lo instaló en la sección anterior [VERIFICADO EN JP 7.2]
sudo apt install -y xfce4 xfce4-goodies

# Configurar NoMachine para usar XFCE4 como escritorio virtual
sudo tee /usr/NX/etc/node.cfg.d/virtual-desktop.cfg > /dev/null << 'EOF'
# Escritorio virtual para sesiones headless
VirtualDesktop 1
DefaultDesktopCommand "startxfce4"
EOF
```

### 2.3.4 Conectar desde Windows

En el cliente NoMachine de Windows (descargado de nomachine.com):
1. Clic en **Add** → tipo de conexión: **NX**
2. Host: `192.168.1.100`, Puerto: `4000`
3. Usuario: `jetson`, Contraseña: la del Jetson
4. Seleccione "Create a new virtual desktop" en la primera conexión

---

## 2.4 GitHub SSH — Clave para el Jetson

Si trabaja con repositorios de GitHub desde el Jetson (código, modelos privados, configuraciones), necesita una clave SSH específica del Jetson en su cuenta de GitHub.

### 2.4.1 Generar la clave SSH

```bash
# Generar clave SSH Ed25519 para GitHub [VERIFICADO EN JP 7.2]
ssh-keygen -t ed25519 \
  -C "jetson-orin-jp72-$(date +%Y%m%d)" \
  -f ~/.ssh/github_ed25519
# Presione Enter cuando pregunte por passphrase (sin contraseña = acceso automático en scripts)

# Mostrar la clave pública para agregarla en GitHub
cat ~/.ssh/github_ed25519.pub
```

```
# Salida esperada — copie esta línea completa
ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAA... jetson-orin-jp72-20260628
```

Agregue esa clave en **github.com/settings/keys** → **New SSH key** → pegue la clave pública.

### 2.4.2 Configurar el cliente SSH del Jetson

```bash
# Crear/actualizar ~/.ssh/config en el Jetson [VERIFICADO EN JP 7.2]
cat >> ~/.ssh/config << 'EOF'

# GitHub — clave específica del Jetson
Host github.com
    HostName github.com
    User git
    IdentityFile ~/.ssh/github_ed25519
    IdentitiesOnly yes
    AddKeysToAgent yes
EOF
chmod 600 ~/.ssh/config

# Verificar conexión
ssh -T git@github.com
```

```
# Salida esperada
Hi tu-usuario! You've successfully authenticated, but GitHub does not provide shell access.
```

### 2.4.3 Configuración global de Git

```bash
# Configurar identidad de commits [VERIFICADO EN JP 7.2]
git config --global user.name "Tu Nombre"
git config --global user.email "tu@email.com"
git config --global core.editor "nano"
git config --global init.defaultBranch main

# Usar SSH en lugar de HTTPS automáticamente
git config --global url."git@github.com:".insteadOf "https://github.com/"
```

---

## 2.5 Variables de Entorno Críticas

Ubuntu 24.04 tiene una restricción importante en `~/.bashrc` que afecta a Docker, systemd y todos los scripts no interactivos: el archivo contiene un bloque `case $- in` que hace `return` anticipado cuando el shell no es interactivo. Cualquier `export` colocado **después** de ese bloque es invisible para Docker, systemd y los scripts.

```bash
# El problema — este bloque existe en ~/.bashrc por defecto
# case $- in
#     *i*) ;;
#       *) return;;   ← TODO lo que esté después de aquí NO se ejecuta
# esac               ← en Docker, systemd, scripts no interactivos
```

La solución es colocar las variables críticas **antes** de ese bloque, al inicio de `~/.bashrc`.

### 2.5.1 Configurar variables al inicio de ~/.bashrc

```bash
# Hacer backup del bashrc actual [VERIFICADO EN JP 7.2]
cp ~/.bashrc ~/.bashrc.backup

# Crear un bloque de exports al inicio del bashrc
# (este comando inserta las líneas AL PRINCIPIO del archivo)
cat > /tmp/bashrc_header.txt << 'HEADER'
# ══════════════════════════════════════════════════════════════════
# EXPORTS GLOBALES — AL INICIO (antes del bloque case $- in)
# Visibles en: shells interactivos, SSH, Docker, systemd, scripts
# ══════════════════════════════════════════════════════════════════

# HuggingFace — reemplazar con su token real de huggingface.co
export HF_TOKEN="hf_SU_TOKEN_AQUI"
export HUGGING_FACE_HUB_TOKEN="$HF_TOKEN"

# vLLM API key local (valor fijo, no es un token de cuenta)
export VLLM_API_KEY="vllm-local"

# CUDA
export CUDA_HOME=/usr/local/cuda
export PATH=/usr/local/cuda/bin:$PATH
export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH

# Python / pipx / npm global
export PATH="$HOME/.npm-global/bin:$PATH"
export PATH="$PATH:$HOME/.local/bin"

# Node.js cache para OpenClaw (reduce tiempo de inicio)
export NODE_COMPILE_CACHE=/var/tmp/openclaw-compile-cache

# PyTorch — arquitectura GPU del Jetson AGX Orin (Ampere sm_87)
export TORCH_CUDA_ARCH_LIST="8.7"

# ══════════════════════════════════════════════════════════════════
HEADER

# Insertar el header al principio del bashrc existente
cat /tmp/bashrc_header.txt ~/.bashrc > /tmp/bashrc_new.txt
mv /tmp/bashrc_new.txt ~/.bashrc
rm /tmp/bashrc_header.txt

source ~/.bashrc
echo "✅ Variables configuradas. HF_TOKEN: ${HF_TOKEN:0:10}..."
```

> **IMPORTANTE:** Reemplace `hf_SU_TOKEN_AQUI` con su token real de HuggingFace. Si aún no tiene un token, puede dejarlo vacío por ahora — es necesario en la Parte 11 (descarga de modelos con acceso controlado como Llama o Gemma). Obtenga el token gratis en **huggingface.co/settings/tokens**.

### 2.5.2 Propagar variables a Docker y systemd

Docker y systemd no leen `~/.bashrc`. Necesitan las variables en `/etc/environment`:

```bash
# Propagar HF_TOKEN a Docker y systemd [VERIFICADO EN JP 7.2]
# (reemplazar hf_SU_TOKEN_AQUI con el token real antes de ejecutar)

sudo tee -a /etc/environment << 'EOF'
HF_TOKEN=hf_SU_TOKEN_AQUI
HUGGING_FACE_HUB_TOKEN=hf_SU_TOKEN_AQUI
VLLM_API_KEY=vllm-local
CUDA_HOME=/usr/local/cuda
TORCH_CUDA_ARCH_LIST=8.7
EOF

# Verificar que no haya duplicados
grep -E "HF_TOKEN|VLLM_API_KEY|CUDA_HOME" /etc/environment
```

```bash
# Guardar también el token en la caché de HuggingFace [VERIFICADO EN JP 7.2]
# Esto evita que hf CLI pida autenticación interactiva en scripts
mkdir -p ~/.cache/huggingface
echo "hf_SU_TOKEN_AQUI" > ~/.cache/huggingface/token
chmod 600 ~/.cache/huggingface/token
echo "✅ Token HuggingFace cacheado"
```

### 2.5.3 Verificación de variables

```bash
# Verificar que las variables están disponibles [VERIFICADO EN JP 7.2]
echo "HF_TOKEN:            ${HF_TOKEN:0:15}..."
echo "VLLM_API_KEY:        $VLLM_API_KEY"
echo "CUDA_HOME:           $CUDA_HOME"
echo "TORCH_CUDA_ARCH:     $TORCH_CUDA_ARCH_LIST"

# Verificar que nvcc está en PATH
nvcc --version | grep "release"

# Verificar que Docker puede ver las variables de sistema
# (esto se comprueba plenamente en la Parte 8, cuando Docker esté instalado)
```

```
# Salida esperada
HF_TOKEN:            hf_oauth_xxxxxxx...
VLLM_API_KEY:        vllm-local
CUDA_HOME:           /usr/local/cuda
TORCH_CUDA_ARCH:     8.7
Cuda compilation tools, release 13.2, V13.2.1
```

---

## 2.6 Herramientas de Monitoreo del Sistema

Antes de continuar con la instalación de software adicional, instale las herramientas de monitoreo que se usarán a lo largo de toda la guía. La más importante es `jtop`, diseñada específicamente para el hardware Jetson.

### 2.6.1 jtop — Monitor de GPU/CPU/Memoria en Tiempo Real

`jtop` es parte del paquete `jetson-stats` y proporciona una vista en tiempo real de CPU, GPU, memoria unificada, temperatura y modo de energía activo. Es la herramienta de diagnóstico principal para el Jetson.

```bash
# Instalar jetson-stats [VERIFICADO EN JP 7.2]
sudo pip3 install jetson-stats

# Si pip3 no está disponible:
sudo apt install -y python3-pip
sudo pip3 install jetson-stats

# Verificar instalación
jtop --version
```

Salida esperada:
```
jtop 4.2.x
```

```bash
# Lanzar jtop (interfaz interactiva — presione 'q' para salir)
jtop
```

`jtop` muestra en tiempo real:
- **Pestaña ALL**: uso de CPU por núcleo, GPU, memoria RAM unificada, temperatura, modo nvpmodel activo
- **Pestaña GPU**: frecuencia GPU, utilización, consumo de energía
- **Pestaña MEM**: desglose de memoria por componente (CPU, GPU, compartida)
- **Pestaña CTRL**: cambio interactivo de modo de energía y `jetson_clocks`

> **NOTA:** `jtop` requiere ser ejecutado como usuario normal (no como root). Si ve el error "Permission denied", asegúrese de no estar usando `sudo jtop`.

### 2.6.2 tegrastats — Monitor de Línea de Comandos

`tegrastats` viene preinstalado con JetPack 7.2. Es útil para scripting y logging porque su salida es parseable:

```bash
# Ver métricas cada segundo durante 10 segundos [VERIFICADO EN JP 7.2]
tegrastats --interval 1000 &
sleep 10
kill %1

# Capturar métricas en un log durante una inferencia:
tegrastats --interval 500 --logfile ~/logs/tegra_$(date +%Y%m%d_%H%M).log &
TEGRA_PID=$!
# ... ejecutar inferencia ...
kill $TEGRA_PID
```

---

## 2.8 Verificación Final del Capítulo

```bash
# Verificación completa del estado tras Parte 2 [VERIFICADO EN JP 7.2]
echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║     VERIFICACIÓN PARTE 2 — RESULTADO         ║"
echo "╚══════════════════════════════════════════════╝"

echo ""
echo "── Boot target ──"
systemctl get-default
# Esperado: multi-user.target

echo ""
echo "── Servicios de acceso remoto ──"
sudo systemctl is-active xrdp   && echo "✅ XRDP activo   (:3389)" || echo "❌ XRDP inactivo"
sudo systemctl is-active nxserver 2>/dev/null \
  && echo "✅ NoMachine activo (:4000)" \
  || sudo /usr/NX/bin/nxserver --status 2>/dev/null | grep "Running" \
  || echo "⚠️  NoMachine: verificar con /usr/NX/bin/nxserver --status"

echo ""
echo "── Display virtual ──"
ls /etc/X11/xorg.conf.d/30-tegra-headless.conf && echo "✅ Config headless presente" || echo "❌ Falta config headless"

echo ""
echo "── GitHub SSH ──"
ssh -T git@github.com 2>&1 | grep -E "success|Hi" && echo "✅ GitHub SSH funciona" || echo "⚠️  GitHub SSH: agregar clave en github.com/settings/keys"

echo ""
echo "── Variables de entorno ──"
[ -n "$HF_TOKEN" ]          && echo "✅ HF_TOKEN configurado"  || echo "⚠️  HF_TOKEN vacío (necesario en Parte 11)"
[ -n "$VLLM_API_KEY" ]      && echo "✅ VLLM_API_KEY: $VLLM_API_KEY" || echo "❌ VLLM_API_KEY no configurado"
[ -n "$TORCH_CUDA_ARCH_LIST" ] && echo "✅ TORCH_CUDA_ARCH_LIST: $TORCH_CUDA_ARCH_LIST" || echo "❌ TORCH_CUDA_ARCH_LIST no configurado"
nvcc --version 2>/dev/null | grep "release" && echo "✅ nvcc en PATH" || echo "❌ nvcc no en PATH"
```

| Error | Causa probable | Solución |
|-------|---------------|---------|
| `multi-user.target` no aparece | Reboot no realizado | `sudo reboot` y esperar |
| XRDP pantalla negra | Variables de sesión faltantes | Revisar sección 2.2.2; instalar XFCE4 |
| NoMachine no conecta | Puerto 4000 bloqueado | Verificar con `sudo ss -tlnp \| grep 4000` |
| `HF_TOKEN` vacío | No colocado antes del bloque `case` | Revisar sección 2.5.1 |
| `nvcc not found` | PATH no propagado | `source ~/.bashrc` o verificar el bloque EXPORTS |

> **Próximo paso:** La Parte 3 cubre el ajuste de rendimiento — modos de energía con `nvpmodel` y bloqueo de frecuencias con `jetson_clocks`. Sin este paso, el Jetson corre a un tercio de su velocidad máxima de inferencia.
