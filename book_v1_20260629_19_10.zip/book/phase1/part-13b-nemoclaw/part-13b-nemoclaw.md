# Parte 13B — NemoClaw: Capa de Seguridad L7 sobre OpenClaw

## Introducción

NemoClaw es el proxy de políticas que envuelve a OpenClaw con tres capas de protección que el gateway por sí solo no tiene: políticas L7 REST (bloqueo selectivo de rutas de API), aislamiento del sistema de archivos (el agente solo accede a directorios explícitamente permitidos) y control de red (puede prohibir que el agente haga solicitudes hacia internet o hacia IPs corporativas).

Esta parte cubre únicamente NemoClaw. Para OpenClaw (gateway principal) consulte la Parte 13A.

**Modo energético:** NemoClaw es un proxy liviano — 30W es suficiente mientras el modelo no está generando activamente.

> **Prerrequisito:** OpenClaw instalado y configurado (Parte 13A). NemoClaw envuelve a OpenClaw — sin OpenClaw, NemoClaw no tiene nada que proteger.

---

## 13B.1 Arquitectura de NemoClaw

```
Arquitectura NemoClaw — JetPack 7.2
═════════════════════════════════════

Navegador / WhatsApp
       │
       ▼  puerto 18789 (loopback)
┌──────────────────────┐
│   NemoClaw Proxy     │   ← Capa de seguridad
│   ─────────────────  │
│   • Políticas L7 REST│   Bloquea rutas de API específicas
│   • Aislamiento FS   │   El agente solo ve directorios permitidos
│   • Control de red   │   Puede prohibir salidas a internet
└──────────────────────┘
       │
       ▼  puerto 18788 (interno)
┌──────────────────────┐
│   OpenClaw Gateway   │   ← Agente central (Parte 13A)
└──────────────────────┘
       │
       ▼
┌──────────────────────┐
│  vLLM :8000          │
│  llama.cpp :8080     │
│  Ollama :11434       │
└──────────────────────┘
```

NemoClaw intercepta todas las solicitudes antes de que lleguen al gateway OpenClaw. Actúa como un firewall de aplicación: puede aprobar, rechazar o modificar cada solicitud basándose en las políticas configuradas.

---

## 13B.2 Instalación

JetPack 7.2 incluye todas las dependencias necesarias. La instalación se reduce a un solo comando:

```bash
# Instalación oficial NVIDIA [VERIFICADO EN JP 7.2]
# Tarda 3-5 minutos — descarga el proxy y configura los servicios
curl -fsSL nvidia.com/nemoclaw.sh | bash
```

```
# Salida esperada:
✅ NemoClaw installed
✅ Dependencies satisfied (JetPack 7.2 detected)
✅ Proxy service configured
→ Run 'nemoclaw start' to activate the security proxy
```

```bash
# Verificar instalación
nemoclaw --version
# Esperado: NemoClaw 2026.x.x
```

> **ADVERTENCIA — Repositorio incorrecto:** El repositorio `github.com/jetsonhacks/NemoClaw-Orin` no existe. Cualquier guía que indique clonarlo está desactualizada. Use exclusivamente el instalador oficial `curl -fsSL nvidia.com/nemoclaw.sh | bash`.

> **IMPORTANTE — Boot limpio:** El instalador configura el servicio pero **NO lo habilita en boot** automáticamente. Esto es correcto para la arquitectura clean-start. Active NemoClaw bajo demanda con `nemoclaw start`.

---

## 13B.3 Gestión del Proxy

```bash
# Verificar estado [VERIFICADO EN JP 7.2]
nemoclaw status
```

```
# Salida esperada:
NemoClaw proxy: running on :18789
OpenClaw gateway: connected (via :18788)
Inference backend: connected
Active policies: 3
```

```bash
# Detener el proxy
nemoclaw stop

# Iniciar el proxy
nemoclaw start

# Reiniciar (útil tras cambio de modelo de inferencia)
nemoclaw restart

# Verificar endpoint de salud del gateway
curl -sf http://localhost:18789/health && echo "✅ Gateway en :18789 activo"
```

---

## 13B.4 Configuración de Inferencia Local (Modo Offline)

Para un despliegue completamente offline y privado, apunte NemoClaw al servidor local:

```bash
# Usar vLLM local como backend [VERIFICADO EN JP 7.2]
nemoclaw config set \
  --inference-provider local \
  --base-url http://localhost:8000/v1 \
  --model qwen35

# Para usar Ollama en lugar de vLLM:
nemoclaw config set \
  --inference-provider local \
  --base-url http://localhost:11434/v1 \
  --model qwen3:7b

# Para usar llama.cpp:
nemoclaw config set \
  --inference-provider local \
  --base-url http://localhost:8080/v1 \
  --model nemotron-omni

# Verificar configuración activa
nemoclaw config show
```

```
# Salida esperada:
inference.provider: local
inference.base-url: http://localhost:8000/v1
inference.model: qwen35
status: connected ✅
```

---

## 13B.5 Configuración de Políticas de Seguridad

### 13B.5.1 Políticas L7 REST — Bloquear Rutas de API

NemoClaw puede bloquear que el agente llame a rutas específicas de la API del sistema:

```bash
# Ver políticas activas [VERIFICADO EN JP 7.2]
nemoclaw policies list

# Bloquear comandos sensibles de sistema de archivos
nemoclaw policies add \
  --rule block-fs-delete \
  --match "POST /api/files/delete" \
  --action deny \
  --reason "El agente no puede borrar archivos del sistema"

# Bloquear acceso a la cámara
nemoclaw policies add \
  --rule block-camera \
  --match "POST /api/camera/*" \
  --action deny

# Bloquear envío de SMS desde el agente
nemoclaw policies add \
  --rule block-sms \
  --match "POST /api/sms/send" \
  --action deny

# Ver las reglas configuradas
nemoclaw policies list --verbose
```

### 13B.5.2 Control de Red

```bash
# Modo offline total: el agente no puede hacer solicitudes a internet
nemoclaw config set network.outbound.mode offline

# Modo allowlist: el agente solo puede contactar hosts específicos
nemoclaw config set network.outbound.mode allowlist
nemoclaw config set network.outbound.allowlist '["localhost","192.168.1.0/24"]'

# Modo por defecto (permisivo): el agente puede contactar cualquier host
nemoclaw config set network.outbound.mode permissive

# Verificar modo activo
nemoclaw config get network.outbound.mode
```

### 13B.5.3 Aislamiento del Sistema de Archivos

```bash
# Definir directorios que el agente puede leer/escribir
nemoclaw config set \
  filesystem.allowedPaths '["/home/jetson/.openclaw/workspace","/tmp/agent-sandbox"]'

# Crear el directorio sandbox si no existe
mkdir -p /tmp/agent-sandbox

# Verificar configuración
nemoclaw config get filesystem.allowedPaths
```

---

## 13B.6 Recuperación Post-Reinicio

NemoClaw no persiste entre reinicios (correcto para la arquitectura clean-start). Secuencia de restauración:

```bash
# Secuencia de restauración post-reinicio [VERIFICADO EN JP 7.2]

# Paso 1: Iniciar el motor de inferencia (PRIMERO — NemoClaw necesita el backend activo)
start-qwen35   # o start-nemotron, start-qwen4b, según el modelo deseado

# Esperar a que el modelo esté disponible
until curl -sf http://localhost:8000/v1/models > /dev/null; do sleep 10; done
echo "✅ Motor de inferencia activo"

# Paso 2: Iniciar OpenClaw gateway
openclaw-start

# Paso 3: Iniciar NemoClaw proxy
nemoclaw start
sleep 3

# Paso 4: Verificar el stack completo
nemoclaw status
curl -sf http://localhost:18789/health && echo "✅ Gateway en :18789 activo"
```

**Script de restauración completo:**

```bash
# Guardar como ~/scripts/start-agent-stack.sh [VERIFICADO EN JP 7.2]
cat > ~/scripts/start-agent-stack.sh << 'EOF'
#!/bin/bash
set -e

MODEL=${1:-"qwen35"}   # parámetro opcional: qwen35, nemotron, qwen4b

echo "Iniciando stack agéntico con modelo: $MODEL"

# 1. Motor de inferencia
case "$MODEL" in
  qwen35)    start-qwen35 ;;
  nemotron)  start-nemotron ;;
  qwen4b)    start-qwen4b ;;
  *)         echo "❌ Modelo desconocido: $MODEL"; exit 1 ;;
esac

# 2. OpenClaw gateway
openclaw gateway start
sleep 5

# 3. NemoClaw proxy
nemoclaw start
sleep 3

# 4. Verificar
nemoclaw status
curl -sf http://localhost:18789/health && echo "✅ Stack completo en :18789"
EOF

chmod +x ~/scripts/start-agent-stack.sh
echo "alias start-stack='~/scripts/start-agent-stack.sh'" >> ~/.bashrc
source ~/.bashrc
```

---

## 13B.7 Monitoreo en Tiempo Real

```bash
# Ver logs del proxy en tiempo real [VERIFICADO EN JP 7.2]
nemoclaw logs --follow

# Filtrar solo solicitudes rechazadas por políticas
nemoclaw logs --follow | grep -i "denied\|blocked\|policy"

# Ver estadísticas de tráfico
nemoclaw stats

# Ver conexiones activas al proxy
ss -tlnp | grep 18789

# Verificar que el proxy está interceptando correctamente
curl -sf http://localhost:18789/health | python3 -m json.tool
```

---

## 13B.8 Aliases para el Día a Día

```bash
# Agregar al ~/.bashrc [VERIFICADO EN JP 7.2]
cat >> ~/.bashrc << 'EOF'

# ── NemoClaw ────────────────────────────────────────────────────────────
alias nemoclaw-start='nemoclaw start && sleep 3 && nemoclaw status'
alias nemoclaw-stop='nemoclaw stop && echo "NemoClaw proxy detenido"'
alias nemoclaw-restart='nemoclaw restart && sleep 3 && nemoclaw status'
alias nemoclaw-status='nemoclaw status'
alias nemoclaw-logs='nemoclaw logs --follow'
alias nemoclaw-policies='nemoclaw policies list --verbose'
EOF

source ~/.bashrc
```

---

## 13B.9 Solución de Problemas

### NemoClaw no arranca después del reinicio

```bash
# Causa más común: el motor de inferencia no está activo
curl -sf http://localhost:8000/v1/models > /dev/null \
  && echo "✅ vLLM activo" \
  || echo "❌ vLLM inactivo — ejecute start-qwen35 primero"

# Después de confirmar el motor, reiniciar
nemoclaw restart
nemoclaw status
```

### El proxy arranca pero OpenClaw no conecta

```bash
# Verificar que el gateway interno de OpenClaw está en el puerto correcto
openclaw gateway status | grep -E "port|running"
# Esperado: running on port 18788 (interno) o 18789 (si NemoClaw no está activo)

# Si OpenClaw muestra puerto 18789 y NemoClaw también intenta tomar 18789:
# solo uno puede estar en ese puerto — detenga el gateway y reinicie el stack
openclaw gateway stop
nemoclaw restart  # NemoClaw tomará 18789 y conectará a OpenClaw en 18788
```

### Las políticas no se aplican

```bash
# Verificar que las políticas están cargadas
nemoclaw policies list

# Recargar políticas sin reiniciar el proxy
nemoclaw policies reload

# Si el problema persiste, reiniciar completamente
nemoclaw restart
```

---

## Resumen de la Parte 13B

NemoClaw añade tres capas de seguridad que OpenClaw no tiene por sí solo:

- **Políticas L7 REST** — bloquea rutas de API específicas antes de que lleguen al agente
- **Aislamiento de sistema de archivos** — el agente solo accede a directorios explícitamente permitidos
- **Control de red** — modo offline, allowlist, o permisivo para las solicitudes salientes del agente

El comando `nemoclaw start` y `nemoclaw restart` son los más usados en el día a día. La instalación correcta usa `curl -fsSL nvidia.com/nemoclaw.sh | bash` — cualquier otro método está desactualizado.

La siguiente parte (13C) cubre Open WebUI: la interfaz gráfica estilo ChatGPT que conecta con todos los motores de inferencia del Jetson desde cualquier navegador de la red local.
